import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withDelay,
  withSpring,
  Easing,
  interpolate,
} from 'react-native-reanimated';
import { useSafeRouter } from '@/hooks/useSafeRouter';
import { useTheme } from '@/hooks/useTheme';
import { ThemedText } from '@/components/ThemedText';

export default function SplashScreen() {
  const { theme } = useTheme();
  const router = useSafeRouter();

  // 动画值
  const logoScale = useSharedValue(0.3);
  const logoOpacity = useSharedValue(0);

  // 左手动画
  const leftHandOpacity = useSharedValue(0);
  const leftHandTranslateX = useSharedValue(-80);
  const leftHandRotate = useSharedValue(0);

  // 书页翻开动画
  const pageRotateY = useSharedValue(0);

  // 右手钢笔动画
  const rightHandOpacity = useSharedValue(0);
  const rightHandTranslateX = useSharedValue(80);
  const penRotate = useSharedValue(0);

  // 最终LOGO动画
  const finalLogoScale = useSharedValue(0);
  const finalLogoOpacity = useSharedValue(0);

  // 文字动画
  const textOpacity = useSharedValue(0);

  useEffect(() => {
    // 动画序列
    // 1. LOGO初步出现 (0-400ms)
    logoOpacity.value = withTiming(1, { duration: 400 });
    logoScale.value = withSpring(1, { damping: 12, stiffness: 100 });

    // 2. 左手从左侧进入 (400-900ms)
    leftHandOpacity.value = withDelay(400, withTiming(1, { duration: 300 }));
    leftHandTranslateX.value = withDelay(
      400,
      withSpring(0, { damping: 15, stiffness: 80 })
    );

    // 3. 左手翻开书页 (800-1400ms)
    leftHandRotate.value = withDelay(
      800,
      withTiming(-45, { duration: 600, easing: Easing.out(Easing.cubic) })
    );
    pageRotateY.value = withDelay(
      800,
      withTiming(-160, { duration: 600, easing: Easing.out(Easing.cubic) })
    );

    // 4. 右手拿钢笔从右侧进入 (1200-1700ms)
    rightHandOpacity.value = withDelay(1200, withTiming(1, { duration: 300 }));
    rightHandTranslateX.value = withDelay(
      1200,
      withSpring(0, { damping: 15, stiffness: 80 })
    );
    penRotate.value = withDelay(
      1400,
      withTiming(-30, { duration: 400, easing: Easing.out(Easing.cubic) })
    );

    // 5. 所有元素合并为最终LOGO (1800-2400ms)
    logoScale.value = withDelay(1800, withTiming(0.8, { duration: 300 }));
    leftHandOpacity.value = withDelay(1800, withTiming(0, { duration: 300 }));
    rightHandOpacity.value = withDelay(1800, withTiming(0, { duration: 300 }));

    finalLogoOpacity.value = withDelay(1900, withTiming(1, { duration: 500 }));
    finalLogoScale.value = withDelay(
      1900,
      withSpring(1.2, { damping: 12, stiffness: 80 })
    );

    // 6. 显示文字 (2400-2800ms)
    textOpacity.value = withDelay(2400, withTiming(1, { duration: 400 }));

    // 7. 跳转到首页 (3200ms)
    const timer = setTimeout(() => {
      router.replace('/home');
    }, 3200);

    return () => clearTimeout(timer);
  }, []);

  // 左手动画样式
  const leftHandStyle = useAnimatedStyle(() => ({
    opacity: leftHandOpacity.value,
    transform: [
      { translateX: leftHandTranslateX.value },
      { rotate: `${leftHandRotate.value}deg` },
    ],
  }));

  // 书页动画样式
  const pageStyle = useAnimatedStyle(() => ({
    transform: [
      { perspective: 1000 },
      { rotateY: `${pageRotateY.value}deg` },
    ],
    opacity: interpolate(pageRotateY.value, [0, -90], [1, 0]),
  }));

  // 右手钢笔动画样式
  const rightHandStyle = useAnimatedStyle(() => ({
    opacity: rightHandOpacity.value,
    transform: [
      { translateX: rightHandTranslateX.value },
    ],
  }));

  const penStyle = useAnimatedStyle(() => ({
    transform: [
      { rotate: `${penRotate.value}deg` },
    ],
  }));

  // 最终LOGO动画样式
  const finalLogoStyle = useAnimatedStyle(() => ({
    opacity: finalLogoOpacity.value,
    transform: [{ scale: finalLogoScale.value }],
  }));

  // 文字动画样式
  const textStyle = useAnimatedStyle(() => ({
    opacity: textOpacity.value,
  }));

  return (
    <View style={[styles.container, { backgroundColor: theme.backgroundRoot }]}>
      {/* 动画舞台 */}
      <View style={styles.stage}>
        {/* 初始书本 */}
        <Animated.View style={[styles.bookContainer, { opacity: logoOpacity, transform: [{ scale: logoScale }] }]}>
          {/* 书本主体 */}
          <View style={styles.book}>
            {/* 左页 */}
            <View style={styles.leftPage}>
              <View style={styles.pageLines}>
                {[1, 2, 3, 4].map((i) => (
                  <View key={i} style={styles.pageLine} />
                ))}
              </View>
            </View>
            {/* 右页 */}
            <View style={styles.rightPage}>
              <View style={styles.pageLines}>
                {[1, 2, 3, 4].map((i) => (
                  <View key={i} style={styles.pageLine} />
                ))}
              </View>
            </View>
            {/* 翻开的书页 */}
            <Animated.View style={[styles.flipPage, pageStyle]}>
              <View style={styles.pageLines}>
                {[1, 2, 3, 4].map((i) => (
                  <View key={i} style={styles.pageLine} />
                ))}
              </View>
            </Animated.View>
          </View>

          {/* 左手 */}
          <Animated.View style={[styles.leftHandContainer, leftHandStyle]}>
            <View style={styles.hand}>
              {/* 手掌 */}
              <View style={styles.palm} />
              {/* 手指 */}
              <View style={[styles.finger, { height: 28, marginLeft: 2 }]} />
              <View style={[styles.finger, { height: 32, marginLeft: -2 }]} />
              <View style={[styles.finger, { height: 28, marginLeft: -2 }]} />
              <View style={[styles.finger, { height: 22, marginLeft: -2 }]} />
            </View>
          </Animated.View>

          {/* 右手拿钢笔 */}
          <Animated.View style={[styles.rightHandContainer, rightHandStyle]}>
            <View style={styles.hand}>
              <View style={styles.palm} />
              <View style={[styles.finger, { height: 20, width: 8 }]} />
              <View style={[styles.finger, { height: 24, width: 8, marginLeft: -3 }]} />
            </View>
            <Animated.View style={[styles.pen, penStyle]}>
              <View style={styles.penBody} />
              <View style={styles.penTip} />
            </Animated.View>
          </Animated.View>
        </Animated.View>

        {/* 最终LOGO - 图标等比例放大版 */}
        <Animated.View style={[styles.finalLogoContainer, finalLogoStyle]}>
          <View style={styles.finalLogo}>
            {/* 圆形背景 */}
            <View style={styles.logoCircle}>
              {/* 书本图标 */}
              <View style={styles.logoBook}>
                <View style={styles.logoLeftPage} />
                <View style={styles.logoRightPage} />
              </View>
              {/* 钢笔图标 */}
              <View style={styles.logoPen}>
                <View style={styles.logoPenBody} />
                <View style={styles.logoPenTip} />
              </View>
            </View>
          </View>
        </Animated.View>
      </View>

      {/* 应用名称 */}
      <Animated.View style={[styles.textContainer, textStyle]}>
        <ThemedText variant="h1" color={theme.textPrimary} style={styles.appName}>
          齐思秒说
        </ThemedText>
        <ThemedText variant="caption" color={theme.textMuted}>
          AI · 第三人称叙事
        </ThemedText>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  stage: {
    width: 300,
    height: 250,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  // 书本容器
  bookContainer: {
    width: 200,
    height: 140,
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center',
  },
  book: {
    flexDirection: 'row',
    width: 160,
    height: 110,
    backgroundColor: '#F5F5F0',
    borderRadius: 4,
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  leftPage: {
    width: 80,
    height: '100%',
    padding: 12,
    backgroundColor: '#FFFEF8',
    borderRightWidth: 1,
    borderRightColor: '#E8E8E0',
    borderTopLeftRadius: 4,
    borderBottomLeftRadius: 4,
  },
  rightPage: {
    width: 80,
    height: '100%',
    padding: 12,
    backgroundColor: '#FFFEF8',
    borderTopRightRadius: 4,
    borderBottomRightRadius: 4,
  },
  flipPage: {
    position: 'absolute',
    left: 80,
    top: 0,
    width: 80,
    height: 110,
    padding: 12,
    backgroundColor: '#FFFEF8',
    borderTopRightRadius: 4,
    borderBottomRightRadius: 4,
    backfaceVisibility: 'hidden',
  },
  pageLines: {
    gap: 10,
  },
  pageLine: {
    height: 2,
    backgroundColor: '#E0E0E0',
    borderRadius: 1,
  },
  // 左手
  leftHandContainer: {
    position: 'absolute',
    left: -50,
    top: 30,
  },
  // 右手
  rightHandContainer: {
    position: 'absolute',
    right: -30,
    bottom: 20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  hand: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  palm: {
    width: 35,
    height: 28,
    backgroundColor: '#FFDAB9',
    borderRadius: 10,
  },
  finger: {
    width: 9,
    height: 24,
    backgroundColor: '#FFDAB9',
    borderRadius: 5,
  },
  // 钢笔
  pen: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: 5,
  },
  penBody: {
    width: 50,
    height: 7,
    backgroundColor: '#1A1A1A',
    borderRadius: 3,
  },
  penTip: {
    width: 0,
    height: 0,
    borderLeftWidth: 10,
    borderLeftColor: '#C8102E',
    borderTopWidth: 3.5,
    borderTopColor: 'transparent',
    borderBottomWidth: 3.5,
    borderBottomColor: 'transparent',
  },
  // 最终LOGO
  finalLogoContainer: {
    position: 'absolute',
    alignItems: 'center',
  },
  finalLogo: {
    alignItems: 'center',
  },
  logoCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    borderWidth: 2.5,
    borderColor: '#1A1A1A',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
  },
  logoBook: {
    flexDirection: 'row',
    width: 50,
    height: 35,
  },
  logoLeftPage: {
    flex: 1,
    backgroundColor: '#F5F5F0',
    borderRightWidth: 1,
    borderRightColor: '#E0E0E0',
    borderTopLeftRadius: 3,
    borderBottomLeftRadius: 3,
  },
  logoRightPage: {
    flex: 1,
    backgroundColor: '#FFFEF8',
    borderTopRightRadius: 3,
    borderBottomRightRadius: 3,
  },
  logoPen: {
    position: 'absolute',
    right: 18,
    bottom: 18,
    flexDirection: 'row',
    alignItems: 'center',
    transform: [{ rotate: '-30deg' }],
  },
  logoPenBody: {
    width: 30,
    height: 5,
    backgroundColor: '#1A1A1A',
    borderRadius: 2,
  },
  logoPenTip: {
    width: 0,
    height: 0,
    borderLeftWidth: 6,
    borderLeftColor: '#C8102E',
    borderTopWidth: 2.5,
    borderTopColor: 'transparent',
    borderBottomWidth: 2.5,
    borderBottomColor: 'transparent',
  },
  // 文字
  textContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  appName: {
    fontWeight: '900',
    letterSpacing: 3,
  },
});
