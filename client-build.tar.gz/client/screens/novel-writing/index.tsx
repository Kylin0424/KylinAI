import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import {
  ScrollView,
  View,
  TouchableOpacity,
  TextInput,
  ActivityIndicator,
  Alert,
  Keyboard,
  Platform,
  KeyboardAvoidingView,
  LayoutAnimation,
  UIManager,
  Modal,
} from 'react-native';
import RNSSE from 'react-native-sse';
import { Feather } from '@expo/vector-icons';
import { useTheme } from '@/hooks/useTheme';
import { Screen } from '@/components/Screen';
import { ThemedText } from '@/components/ThemedText';
import { useSafeRouter, useSafeSearchParams } from '@/hooks/useSafeRouter';
import { useFocusEffect } from 'expo-router';
import { createStyles } from './styles';
import { FloatingBall } from '@/components/FloatingBall';
import {
  Novel,
  getNovelById,
  updateNovelContent,
  addChapter,
  updateChapter,
} from '@/utils/novelStorage';
import {
  Character,
  getCharacterById,
} from '@/utils/characterStorage';
import { NOVEL_THEME_TYPES } from '@/constants/occupations';

// 启用 Android 的 LayoutAnimation
if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const EXPO_PUBLIC_BACKEND_BASE_URL = process.env.EXPO_PUBLIC_BACKEND_BASE_URL || '';

type InputMode = 'manual' | 'voice';

// 常用标点符号
const PUNCTUATION_MARKS: string[] = [
  String.fromCharCode(0xFF0C), // 逗号
  String.fromCharCode(0x3002), // 句号
  String.fromCharCode(0xFF01), // 感叹号
  String.fromCharCode(0xFF1F), // 问号
  String.fromCharCode(0x3001), // 顿号
  String.fromCharCode(0xFF1A), // 冒号
  String.fromCharCode(0xFF1B), // 分号
  String.fromCharCode(0x201C), // 左双引号
  String.fromCharCode(0x201D), // 右双引号
  String.fromCharCode(0x2018), // 左单引号
  String.fromCharCode(0x2019), // 右单引号
  String.fromCharCode(0x3010), // 左方括号
  String.fromCharCode(0x3011), // 右方括号
];

export default function NovelWritingScreen() {
  const { theme, isDark } = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const router = useSafeRouter();
  const params = useSafeSearchParams<{
    novelId: string;
    worldName?: string;
    eraBackground?: string;
    seasonSetting?: string;
    autoGeneratePrologue?: string;
  }>();

  const [novel, setNovel] = useState<Novel | null>(null);
  const [maleCharacter, setMaleCharacter] = useState<Character | null>(null);
  const [femaleCharacter, setFemaleCharacter] = useState<Character | null>(null);
  const [content, setContent] = useState('');
  const [currentChapterId, setCurrentChapterId] = useState<string | null>(null);
  const [currentChapterName, setCurrentChapterName] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showChapterList, setShowChapterList] = useState(false);
  const [showChapterInput, setShowChapterInput] = useState(false);
  const [newChapterName, setNewChapterName] = useState('');
  const [inputMode, setInputMode] = useState<InputMode>('manual');
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);

  // 楔子生成状态
  const [isGeneratingPrologue, setIsGeneratingPrologue] = useState(false);
  const [prologueContent, setPrologueContent] = useState('');
  const hasGeneratedPrologue = useRef(false);

  // AI续写弹窗
  const [showContinueModal, setShowContinueModal] = useState(false);
  const [continueDirection, setContinueDirection] = useState('');

  // 角色详情弹窗
  const [showCharacterModal, setShowCharacterModal] = useState(false);
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);

  // 文本格式设置
  const [textFormat, setTextFormat] = useState({
    fontFamily: '黑体',
    fontSize: 16,
    isBold: false,
    boldLevel: 1,
    isItalic: false,
    isUnderline: false,
    isStrikethrough: false,
    highlightColor: null as string | null,
  });

  // 格式设置弹窗
  const [showFormatModal, setShowFormatModal] = useState(false);
  const [formatModalType, setFormatModalType] = useState<'font' | 'fontSize' | 'bold' | 'highlight' | null>(null);

  // 查找替换功能
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [searchText, setSearchText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [searchResults, setSearchResults] = useState<{
    exact: { index: number; text: string; isAI?: boolean }[];
    synonyms: { index: number; text: string; synonym: string }[];
  }>({ exact: [], synonyms: [] });
  const [isSearching, setIsSearching] = useState(false);
  const [currentSearchIndex, setCurrentSearchIndex] = useState(0);

  // 可选字体
  const FONT_OPTIONS = ['黑体', '宋体', '楷体', '仿宋', '默认字体'];

  // 可选字号
  const FONT_SIZE_OPTIONS = [12, 14, 16, 18, 20, 22, 24];

  // 加粗档位
  const BOLD_OPTIONS = [
    { label: '轻度', value: 1, fontWeight: '500' as const },
    { label: '中度', value: 2, fontWeight: '600' as const },
    { label: '重度', value: 3, fontWeight: '700' as const },
  ];

  // 标记线颜色
  const HIGHLIGHT_COLORS = [
    { label: '红色', value: '#EF4444' },
    { label: '橙色', value: '#F97316' },
    { label: '黄色', value: '#EAB308' },
    { label: '绿色', value: '#22C55E' },
    { label: '蓝色', value: '#3B82F6' },
    { label: '紫色', value: '#8B5CF6' },
  ];

  // 自动保存相关
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastSavedContentRef = useRef<string>('');
  const scrollViewRef = useRef<ScrollView>(null);
  const textInputRef = useRef<TextInput>(null);

  // 加载数据
  const loadData = async () => {
    if (!params.novelId) return;

    setIsLoading(true);
    const novelData = await getNovelById(params.novelId);
    setNovel(novelData);

    if (novelData) {
      setContent(novelData.content);

      // 加载角色
      if (novelData.maleCharacterId) {
        const male = await getCharacterById(novelData.maleCharacterId);
        setMaleCharacter(male);
      }
      if (novelData.femaleCharacterId) {
        const female = await getCharacterById(novelData.femaleCharacterId);
        setFemaleCharacter(female);
      }
    }

    setIsLoading(false);
  };

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [params.novelId])
  );

  // 自动生成楔子
  useEffect(() => {
    if (
      params.autoGeneratePrologue === 'true' &&
      params.worldName &&
      novel &&
      !hasGeneratedPrologue.current
    ) {
      hasGeneratedPrologue.current = true;
      generatePrologue();
    }
  }, [params.autoGeneratePrologue, params.worldName, novel]);

  // 生成楔子
  const generatePrologue = async () => {
    if (!novel || !params.worldName) return;

    setIsGeneratingPrologue(true);
    setPrologueContent('');

    try {
      const url = `${EXPO_PUBLIC_BACKEND_BASE_URL}/api/v1/novel/prologue`;
      const body = JSON.stringify({
        worldName: params.worldName,
        eraBackground: params.eraBackground || '现代社会',
        seasonSetting: params.seasonSetting || '春季',
        title: novel.title,
        maleCharacter: maleCharacter,
        femaleCharacter: femaleCharacter,
      });

      const sse = new RNSSE(url, {
        headers: { 'Content-Type': 'application/json' },
        method: 'POST',
        body: body,
      });

      let fullContent = '';

      sse.addEventListener('message', async (event) => {
        if (event.data === '[DONE]') {
          // 生成完成，保存楔子章节
          if (fullContent) {
            const chapter = await addChapter(novel.id, '楔子');
            await updateChapter(novel.id, chapter.id, { content: fullContent });
            // 更新小说数据
            const updatedNovel = await getNovelById(novel.id);
            setNovel(updatedNovel);
          }
          sse.close();
          setIsGeneratingPrologue(false);
          return;
        }

        try {
          const parsed = JSON.parse(event.data || '{}');
          if (parsed.content) {
            fullContent += parsed.content;
            setPrologueContent(fullContent);
          }
        } catch (e) {
          // 忽略解析错误
        }
      });

      sse.addEventListener('error', (error) => {
        console.error('SSE error:', error);
        sse.close();
        setIsGeneratingPrologue(false);
        Alert.alert('错误', '生成楔子失败，请重试');
      });
    } catch (error) {
      console.error('Prologue generation error:', error);
      setIsGeneratingPrologue(false);
      Alert.alert('错误', '生成楔子失败，请重试');
    }
  };

  // 监听键盘状态
  useEffect(() => {
    const keyboardWillShow = Keyboard.addListener(
      Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow',
      () => {
        setIsKeyboardVisible(true);
      }
    );
    const keyboardWillHide = Keyboard.addListener(
      Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide',
      () => {
        setIsKeyboardVisible(false);
      }
    );

    return () => {
      keyboardWillShow.remove();
      keyboardWillHide.remove();
    };
  }, []);

  // 自动保存
  const saveContent = async () => {
    if (!novel || content === lastSavedContentRef.current) return;

    try {
      await updateNovelContent(novel.id, content);
      lastSavedContentRef.current = content;
    } catch (error) {
      console.error('Auto save error:', error);
    }
  };

  // 防抖保存
  useEffect(() => {
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }

    saveTimeoutRef.current = setTimeout(() => {
      saveContent();
    }, 1000);

    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }
    };
  }, [content]);

  // 退出时保存
  useEffect(() => {
    return () => {
      if (content !== lastSavedContentRef.current && novel) {
        updateNovelContent(novel.id, content);
      }
    };
  }, [content, novel]);

  // 切换输入模式
  const toggleInputMode = () => {
    LayoutAnimation.easeInEaseOut();
    if (inputMode === 'manual') {
      setInputMode('voice');
      Keyboard.dismiss();
    } else {
      setInputMode('manual');
    }
  };

  // 插入标点符号
  const insertPunctuation = (mark: string) => {
    if (textInputRef.current) {
      setContent(prev => prev + mark);
      textInputRef.current?.focus();
    }
  };

  // 打开格式设置弹窗
  const openFormatModal = (type: 'font' | 'fontSize' | 'bold' | 'highlight') => {
    setFormatModalType(type);
    setShowFormatModal(true);
  };

  // 切换加粗
  const toggleBold = () => {
    setTextFormat(prev => ({ ...prev, isBold: !prev.isBold }));
  };

  // 设置加粗档位
  const setBoldLevel = (level: number) => {
    setTextFormat(prev => ({ ...prev, boldLevel: level, isBold: true }));
    setShowFormatModal(false);
  };

  // 切换斜体
  const toggleItalic = () => {
    setTextFormat(prev => ({ ...prev, isItalic: !prev.isItalic }));
  };

  // 切换下划线
  const toggleUnderline = () => {
    setTextFormat(prev => ({ ...prev, isUnderline: !prev.isUnderline }));
  };

  // 切换删除线
  const toggleStrikethrough = () => {
    setTextFormat(prev => ({ ...prev, isStrikethrough: !prev.isStrikethrough }));
  };

  // 设置字体
  const setFontFamily = (font: string) => {
    setTextFormat(prev => ({ ...prev, fontFamily: font }));
    setShowFormatModal(false);
  };

  // 设置字号
  const setFontSize = (size: number) => {
    setTextFormat(prev => ({ ...prev, fontSize: size }));
    setShowFormatModal(false);
  };

  // 设置标记线颜色
  const setHighlightColor = (color: string | null) => {
    setTextFormat(prev => ({ ...prev, highlightColor: color }));
    setShowFormatModal(false);
  };

  // 清除所有格式
  const clearAllFormats = () => {
    setTextFormat({
      fontFamily: '黑体',
      fontSize: 16,
      isBold: false,
      boldLevel: 1,
      isItalic: false,
      isUnderline: false,
      isStrikethrough: false,
      highlightColor: null,
    });
  };

  // 获取当前字体粗细
  const getCurrentFontWeight = () => {
    if (!textFormat.isBold) return '400';
    const boldOption = BOLD_OPTIONS.find(o => o.value === textFormat.boldLevel);
    return boldOption?.fontWeight || '600';
  };

  // 执行搜索（包括AI近义词）
  const performSearch = async (keyword: string) => {
    if (!keyword.trim()) {
      setSearchResults({ exact: [], synonyms: [] });
      return;
    }

    setIsSearching(true);
    const exactResults: { index: number; text: string }[] = [];
    const synonymResults: { index: number; text: string; synonym: string }[] = [];

    // 1. 精确匹配搜索
    let searchPos = 0;
    while (true) {
      const index = content.indexOf(keyword, searchPos);
      if (index === -1) break;
      exactResults.push({ index, text: keyword });
      searchPos = index + keyword.length;
    }

    // 2. AI近义词搜索
    try {
      const response = await fetch(`${EXPO_PUBLIC_BACKEND_BASE_URL}/api/v1/search/synonyms`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword }),
      });

      if (response.ok) {
        const data = await response.json();
        const synonyms = data.synonyms || [];

        // 对每个近义词进行搜索
        for (const synonym of synonyms) {
          let synPos = 0;
          while (true) {
            const synIndex = content.indexOf(synonym, synPos);
            if (synIndex === -1) break;
            // 避免与精确匹配重复
            const isDuplicate = exactResults.some(
              r => r.index === synIndex && r.text === synonym
            );
            if (!isDuplicate) {
              synonymResults.push({ index: synIndex, text: synonym, synonym });
            }
            synPos = synIndex + synonym.length;
          }
        }
      }
    } catch (error) {
      console.error('AI synonym search error:', error);
    }

    setSearchResults({ exact: exactResults, synonyms: synonymResults });
    setCurrentSearchIndex(0);
    setIsSearching(false);
  };

  // 替换单个结果
  const replaceSingle = (index: number, originalText: string) => {
    if (!replaceText.trim()) return;
    const newContent = content.substring(0, index) + replaceText + content.substring(index + originalText.length);
    setContent(newContent);
    // 重新搜索
    performSearch(searchText);
  };

  // 一键全部替换
  const replaceAll = () => {
    if (!replaceText.trim() || (searchResults.exact.length === 0 && searchResults.synonyms.length === 0)) return;

    // 从后往前替换，避免索引变化
    const allResults = [
      ...searchResults.exact.map(r => ({ ...r, isSynonym: false })),
      ...searchResults.synonyms.map(r => ({ index: r.index, text: r.text, isSynonym: true })),
    ].sort((a, b) => b.index - a.index);

    let newContent = content;
    for (const result of allResults) {
      newContent = newContent.substring(0, result.index) + replaceText + newContent.substring(result.index + result.text.length);
    }
    setContent(newContent);
    setSearchResults({ exact: [], synonyms: [] });
  };

  // 打开搜索弹窗
  const openSearchModal = () => {
    setShowSearchModal(true);
    setSearchText('');
    setReplaceText('');
    setSearchResults({ exact: [], synonyms: [] });
  };

  // 打开AI续写弹窗
  const handleOpenContinueModal = () => {
    setShowContinueModal(true);
    setContinueDirection('');
  };

  // 生成小说内容
  const handleGenerate = async () => {
    if (!novel) return;

    setIsGenerating(true);
    setShowContinueModal(false);

    try {
      const themeType = NOVEL_THEME_TYPES.find(t => t.id === novel.themeType);
      const themeName = themeType?.name || '都市';

      const prompt = `请继续创作以下小说：

小说标题：${novel.title}
主题类型：${themeName}

主要角色：
${maleCharacter ? `- 男主角：${maleCharacter.name}，${maleCharacter.occupation}，${maleCharacter.age}岁。性格：${maleCharacter.personality?.substring(0, 100) || '未知'}` : ''}
${femaleCharacter ? `- 女主角：${femaleCharacter.name}，${femaleCharacter.occupation}，${femaleCharacter.age}岁。性格：${femaleCharacter.personality?.substring(0, 100) || '未知'}` : ''}

章节大纲：
${novel.chapters.map((ch, i) => `${i + 1}. ${ch.title}`).join('\n')}

已有内容：
${content || '（暂无内容，请开始创作第一章）'}

${continueDirection ? `续写走向要求：${continueDirection}` : ''}

请继续创作小说内容（约500-800字），保持第三人称叙事风格，注意情节连贯性和角色性格的一致性。`;

      const response = await fetch(`${EXPO_PUBLIC_BACKEND_BASE_URL}/api/v1/novel/continue`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          prompt,
          title: novel.title,
          themeType: novel.themeType,
          maleCharacter: maleCharacter ? {
            name: maleCharacter.name,
            occupation: maleCharacter.occupation,
            personality: maleCharacter.personality,
          } : null,
          femaleCharacter: femaleCharacter ? {
            name: femaleCharacter.name,
            occupation: femaleCharacter.occupation,
            personality: femaleCharacter.personality,
          } : null,
        }),
      });

      if (!response.ok) {
        throw new Error('生成失败');
      }

      const data = await response.json();
      setContent(prev => prev + '\n\n' + data.content);
      setContinueDirection(''); // 清空续写走向
    } catch (error) {
      console.error('Novel generation error:', error);
      Alert.alert('错误', '生成内容失败，请重试');
    } finally {
      setIsGenerating(false);
    }
  };

  // 添加章节
  const handleAddChapter = async () => {
    if (!novel) return;
    setShowChapterInput(true);
    // 自动预填章节序号
    const nextChapterNum = novel.chapters.length + 1;
    setNewChapterName(`第${nextChapterNum}章 `);
  };

  // 确认添加章节
  const confirmAddChapter = async () => {
    if (!novel) return;
    if (newChapterName.trim()) {
      const chapter = await addChapter(novel.id, newChapterName.trim());
      setNovel(prev => prev ? { ...prev, chapters: [...prev.chapters, chapter] } : null);
      setShowChapterInput(false);
      setNewChapterName('');
    }
  };

  // 选择章节
  const handleSelectChapter = (chapterId: string, chapterTitle: string) => {
    setCurrentChapterId(chapterId);
    setCurrentChapterName(chapterTitle);
    setShowChapterList(false);
  };

  // 返回首页
  const handleBack = () => {
    if (content !== lastSavedContentRef.current && novel) {
      updateNovelContent(novel.id, content).then(() => {
        router.push('/home');
      });
    } else {
      router.push('/home');
    }
  };

  // 处理内容变化并保持光标可见
  const handleContentSizeChange = (width: number, height: number) => {
    if (isKeyboardVisible && scrollViewRef.current) {
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  };

  // 语音输入（模拟）
  const handleVoiceInput = () => {
    Alert.alert('语音输入', '语音输入功能开发中，敬请期待');
  };

  if (isLoading) {
    return (
      <Screen backgroundColor={theme.backgroundRoot} statusBarStyle={isDark ? 'light' : 'dark'}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#C8102E" />
        </View>
      </Screen>
    );
  }

  if (!novel) {
    return (
      <Screen backgroundColor={theme.backgroundRoot} statusBarStyle={isDark ? 'light' : 'dark'}>
        <View style={styles.errorContainer}>
          <Feather name="alert-circle" size={48} color={theme.textMuted} />
          <ThemedText variant="small" color={theme.textMuted} style={{ marginTop: 12 }}>
            小说不存在
          </ThemedText>
          <TouchableOpacity style={styles.backButton} onPress={() => router.push('/home')}>
            <ThemedText variant="smallMedium" color="#C8102E">返回首页</ThemedText>
          </TouchableOpacity>
        </View>
      </Screen>
    );
  }

  const themeType = NOVEL_THEME_TYPES.find(t => t.id === novel.themeType);

  return (
    <Screen backgroundColor={theme.backgroundRoot} statusBarStyle={isDark ? 'light' : 'dark'}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
      >
        {/* 顶部工具栏 - 缩小 */}
        <View style={styles.topBar}>
          <TouchableOpacity style={styles.topBarButton} onPress={handleBack}>
            <Feather name="arrow-left" size={18} color={theme.textPrimary} />
          </TouchableOpacity>

          <View style={styles.novelInfo}>
            <ThemedText variant="small" color={theme.textPrimary} numberOfLines={1}>
              {novel.title}
            </ThemedText>
            <TouchableOpacity
              style={styles.chapterSelector}
              onPress={() => setShowChapterList(!showChapterList)}
            >
              <ThemedText variant="caption" color={theme.textMuted} numberOfLines={1}>
                {currentChapterName || '选择章节'}
              </ThemedText>
              <Feather name="chevron-down" size={12} color={theme.textMuted} />
            </TouchableOpacity>
          </View>

          <View style={styles.topBarRight}>
            <ThemedText variant="caption" color={theme.textMuted}>
              {content.length}字
            </ThemedText>
            <TouchableOpacity style={styles.searchButton} onPress={openSearchModal}>
              <Feather name="search" size={16} color={theme.textPrimary} />
            </TouchableOpacity>
          </View>
        </View>

        {/* 章节选择下拉 */}
        {showChapterList && (
          <View style={styles.chapterDropdown}>
            <View style={styles.chapterDropdownHeader}>
              <ThemedText variant="small" color={theme.textPrimary}>章节</ThemedText>
              <TouchableOpacity onPress={handleAddChapter}>
                <Feather name="plus" size={18} color="#C8102E" />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.chapterDropdownList}>
              {novel.chapters.map((chapter, index) => (
                <TouchableOpacity
                  key={chapter.id}
                  style={[
                    styles.chapterDropdownItem,
                    currentChapterId === chapter.id && styles.chapterDropdownItemActive,
                  ]}
                  onPress={() => handleSelectChapter(chapter.id, chapter.title)}
                >
                  <ThemedText
                    variant="caption"
                    color={currentChapterId === chapter.id ? '#C8102E' : theme.textPrimary}
                    numberOfLines={1}
                  >
                    第{index + 1}章 {chapter.title}
                  </ThemedText>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* 楔子生成区域 */}
        {isGeneratingPrologue && (
          <View style={styles.prologueGeneratingContainer}>
            <View style={styles.prologueHeader}>
              <ActivityIndicator size="small" color="#C8102E" />
              <ThemedText variant="small" color="#C8102E" style={styles.prologueHeaderText}>
                正在生成第零章-楔子...
              </ThemedText>
            </View>
            <View style={styles.prologueContentBox}>
              <ThemedText variant="body" color={theme.textPrimary} style={styles.prologueContentText}>
                {prologueContent || '正在构思中...'}
              </ThemedText>
            </View>
            <View style={styles.prologueHint}>
              <ThemedText variant="caption" color={theme.textMuted}>
                世界：{params.worldName} · 年代：{params.eraBackground || '现代社会'} · 季节：{params.seasonSetting || '春季'}
              </ThemedText>
            </View>
          </View>
        )}

        {/* 书写区域 - 最大化 */}
        <ScrollView
          ref={scrollViewRef}
          style={styles.writingArea}
          contentContainerStyle={[
            styles.writingContent,
            isKeyboardVisible && styles.writingContentKeyboard,
          ]}
          keyboardDismissMode="interactive"
          keyboardShouldPersistTaps="handled"
        >
          <TextInput
            ref={textInputRef}
            style={[
              styles.contentInput, 
              {
                fontSize: textFormat.fontSize,
                fontFamily: textFormat.fontFamily === '默认字体' ? undefined : textFormat.fontFamily,
                fontWeight: getCurrentFontWeight(),
                fontStyle: textFormat.isItalic ? 'italic' : 'normal',
                textDecorationLine: [
                  textFormat.isUnderline ? 'underline' : undefined,
                  textFormat.isStrikethrough ? 'line-through' : undefined,
                ].filter(Boolean).join(' ') as any || 'none',
                lineHeight: textFormat.fontSize * 1.6,
              }
            ]}
            value={content}
            onChangeText={setContent}
            placeholder="开始创作你的故事..."
            placeholderTextColor={theme.textMuted}
            multiline
            textAlignVertical="top"
            editable={inputMode === 'manual'}
            onContentSizeChange={(e) => handleContentSizeChange(e.nativeEvent.contentSize.width, e.nativeEvent.contentSize.height)}
            scrollEnabled={false}
          />
        </ScrollView>

        {/* 底部工具栏 - 紧凑布局 */}
        <View style={styles.inputToolbar}>
          {/* 格式工具栏 */}
          <View style={styles.formatToolbar}>
            {/* 字体选择 */}
            <TouchableOpacity 
              style={styles.formatBtn}
              onPress={() => openFormatModal('font')}
            >
              <Feather name="type" size={14} color={theme.textPrimary} />
              <ThemedText variant="caption" color={theme.textMuted} style={{ marginLeft: 2 }}>
                {textFormat.fontFamily}
              </ThemedText>
            </TouchableOpacity>

            {/* 字号选择 */}
            <TouchableOpacity 
              style={styles.formatBtn}
              onPress={() => openFormatModal('fontSize')}
            >
              <ThemedText variant="small" color={theme.textPrimary} style={{ fontWeight: '600' }}>
                {textFormat.fontSize}
              </ThemedText>
            </TouchableOpacity>

            {/* 分隔线 */}
            <View style={styles.formatDivider} />

            {/* 加粗 */}
            <TouchableOpacity 
              style={[styles.formatBtn, textFormat.isBold && styles.formatBtnActive]}
              onPress={toggleBold}
            >
              <ThemedText 
                variant="small" 
                color={textFormat.isBold ? '#C8102E' : theme.textPrimary}
                style={{ fontWeight: '700' }}
              >
                B
              </ThemedText>
            </TouchableOpacity>

            {/* 斜体 */}
            <TouchableOpacity 
              style={[styles.formatBtn, textFormat.isItalic && styles.formatBtnActive]}
              onPress={toggleItalic}
            >
              <ThemedText 
                variant="small" 
                color={textFormat.isItalic ? '#C8102E' : theme.textPrimary}
                style={{ fontStyle: 'italic' }}
              >
                I
              </ThemedText>
            </TouchableOpacity>

            {/* 下划线 */}
            <TouchableOpacity 
              style={[styles.formatBtn, textFormat.isUnderline && styles.formatBtnActive]}
              onPress={toggleUnderline}
            >
              <ThemedText 
                variant="small" 
                color={textFormat.isUnderline ? '#C8102E' : theme.textPrimary}
                style={{ textDecorationLine: 'underline' }}
              >
                U
              </ThemedText>
            </TouchableOpacity>

            {/* 删除线 */}
            <TouchableOpacity 
              style={[styles.formatBtn, textFormat.isStrikethrough && styles.formatBtnActive]}
              onPress={toggleStrikethrough}
            >
              <ThemedText 
                variant="small" 
                color={theme.textPrimary}
                style={{ textDecorationLine: 'line-through' }}
              >
                S
              </ThemedText>
            </TouchableOpacity>

            {/* 标记线 */}
            <TouchableOpacity 
              style={[styles.formatBtn, textFormat.highlightColor && styles.formatBtnActive]}
              onPress={() => openFormatModal('highlight')}
            >
              <View style={[
                styles.highlightIcon, 
                textFormat.highlightColor && { borderColor: textFormat.highlightColor }
              ]}>
                <Feather name="circle" size={12} color={textFormat.highlightColor || theme.textMuted} />
              </View>
            </TouchableOpacity>

            {/* 清除格式 */}
            <TouchableOpacity 
              style={styles.formatBtn}
              onPress={clearAllFormats}
            >
              <Feather name="x-circle" size={14} color={theme.textMuted} />
            </TouchableOpacity>
          </View>

          {/* 角色信息栏 - 缩小 */}
          <View style={styles.characterBar}>
            {maleCharacter && (
              <TouchableOpacity 
                style={styles.characterChip}
                onPress={() => {
                  setSelectedCharacter(maleCharacter);
                  setShowCharacterModal(true);
                }}
              >
                <ThemedText variant="caption" color="#C8102E">男主角：</ThemedText>
                <ThemedText variant="caption" color={theme.textPrimary} numberOfLines={1}>
                  {maleCharacter.name}
                </ThemedText>
                <Feather name="info" size={12} color={theme.textMuted} style={{ marginLeft: 2 }} />
              </TouchableOpacity>
            )}
            {femaleCharacter && (
              <TouchableOpacity 
                style={styles.characterChip}
                onPress={() => {
                  setSelectedCharacter(femaleCharacter);
                  setShowCharacterModal(true);
                }}
              >
                <ThemedText variant="caption" color="#C8102E">女主角：</ThemedText>
                <ThemedText variant="caption" color={theme.textPrimary} numberOfLines={1}>
                  {femaleCharacter.name}
                </ThemedText>
                <Feather name="info" size={12} color={theme.textMuted} style={{ marginLeft: 2 }} />
              </TouchableOpacity>
            )}
          </View>

          {/* 输入控制栏 */}
          <View style={styles.controlBar}>
            {/* 左侧：输入模式 */}
            <TouchableOpacity style={styles.modeButton} onPress={toggleInputMode}>
              <Feather
                name={inputMode === 'manual' ? 'edit-3' : 'mic'}
                size={14}
                color={inputMode === 'manual' ? theme.textPrimary : '#C8102E'}
              />
              <ThemedText
                variant="caption"
                color={inputMode === 'manual' ? theme.textMuted : '#C8102E'}
                style={{ marginLeft: 4 }}
              >
                {inputMode === 'manual' ? '手动' : '语音'}
              </ThemedText>
            </TouchableOpacity>

            {/* 中间：标点符号快捷输入 */}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.punctuationBar}
              contentContainerStyle={styles.punctuationContent}
            >
              {PUNCTUATION_MARKS.map((mark, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.punctuationBtn}
                  onPress={() => insertPunctuation(mark)}
                >
                  <ThemedText variant="small" color={theme.textPrimary}>{mark}</ThemedText>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* 右侧：AI续写 */}
            <TouchableOpacity
              style={[styles.aiButton, isGenerating && styles.aiButtonDisabled]}
              onPress={handleOpenContinueModal}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <>
                  <Feather name="feather" size={14} color="#FFFFFF" />
                  <ThemedText variant="caption" color="#FFFFFF" style={{ marginLeft: 4 }}>
                    AI续写
                  </ThemedText>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>

        {/* 语音输入按钮（语音模式下显示） */}
        {inputMode === 'voice' && (
          <TouchableOpacity style={styles.voiceButton} onPress={handleVoiceInput}>
            <View style={styles.voiceButtonInner}>
              <Feather name="mic" size={24} color="#FFFFFF" />
            </View>
            <ThemedText variant="caption" color={theme.textMuted} style={{ marginTop: 8 }}>
              点击开始语音输入
            </ThemedText>
          </TouchableOpacity>
        )}
      </KeyboardAvoidingView>

      {/* 添加章节对话框 */}
      {showChapterInput && (
        <View style={styles.chapterInputOverlay}>
          <View style={styles.chapterInputDialog}>
            <ThemedText variant="small" color={theme.textPrimary} style={styles.chapterInputTitle}>
              添加章节
            </ThemedText>
            <TextInput
              style={styles.chapterInputField}
              value={newChapterName}
              onChangeText={setNewChapterName}
              placeholder="请输入章节名称"
              placeholderTextColor={theme.textMuted}
              autoFocus
            />
            <View style={styles.chapterInputActions}>
              <TouchableOpacity
                style={styles.chapterInputCancel}
                onPress={() => {
                  setShowChapterInput(false);
                  setNewChapterName('');
                }}
              >
                <ThemedText variant="small" color={theme.textMuted}>取消</ThemedText>
              </TouchableOpacity>
              <TouchableOpacity style={styles.chapterInputConfirm} onPress={confirmAddChapter}>
                <ThemedText variant="small" color="#FFFFFF">确定</ThemedText>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      )}

      {/* AI续写弹窗 */}
      <Modal
        visible={showContinueModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowContinueModal(false)}
      >
        <View style={styles.continueModalOverlay}>
          <View style={styles.continueModalContent}>
            <View style={styles.continueModalHeader}>
              <ThemedText variant="smallMedium" color={theme.textPrimary}>
                AI续写
              </ThemedText>
              <TouchableOpacity onPress={() => setShowContinueModal(false)}>
                <Feather name="x" size={22} color={theme.textPrimary} />
              </TouchableOpacity>
            </View>

            <ThemedText variant="caption" color={theme.textMuted} style={{ marginBottom: 8 }}>
              输入续写走向（可选）
            </ThemedText>

            <TextInput
              style={styles.continueInput}
              value={continueDirection}
              onChangeText={setContinueDirection}
              placeholder="例如：主角发现了一个惊天秘密..."
              placeholderTextColor={theme.textMuted}
              multiline
              numberOfLines={3}
              autoFocus
            />

            <View style={styles.continueQuickOptions}>
              <TouchableOpacity
                style={styles.quickOption}
                onPress={() => setContinueDirection('情节出现意外转折')}
              >
                <ThemedText variant="caption" color="#C8102E">意外转折</ThemedText>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.quickOption}
                onPress={() => setContinueDirection('增加浪漫情节')}
              >
                <ThemedText variant="caption" color="#C8102E">浪漫情节</ThemedText>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.quickOption}
                onPress={() => setContinueDirection('引入新角色')}
              >
                <ThemedText variant="caption" color="#C8102E">引入新角色</ThemedText>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.quickOption}
                onPress={() => setContinueDirection('增加悬念')}
              >
                <ThemedText variant="caption" color="#C8102E">增加悬念</ThemedText>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.continueGenerateButton}
              onPress={handleGenerate}
              disabled={isGenerating}
            >
              {isGenerating ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <>
                  <Feather name="feather" size={16} color="#FFFFFF" />
                  <ThemedText variant="small" color="#FFFFFF" style={{ marginLeft: 8 }}>
                    开始续写
                  </ThemedText>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* 角色详情弹窗 */}
      <Modal
        visible={showCharacterModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowCharacterModal(false)}
      >
        <TouchableOpacity 
          style={styles.characterModalOverlay}
          activeOpacity={1}
          onPress={() => setShowCharacterModal(false)}
        >
          <TouchableOpacity 
            style={styles.characterModalContent}
            activeOpacity={1}
            onPress={() => {}}
          >
            <View style={styles.characterModalHeader}>
              <View style={styles.characterModalTitleRow}>
                <View style={[styles.characterAvatar, { backgroundColor: selectedCharacter?.gender === '男' ? '#3B82F6' : '#EC4899' }]}>
                  <Feather name="user" size={20} color="#FFFFFF" />
                </View>
                <View>
                  <ThemedText variant="smallMedium" color={theme.textPrimary}>
                    {selectedCharacter?.name}
                  </ThemedText>
                  <ThemedText variant="caption" color={theme.textMuted}>
                    {selectedCharacter?.gender === '男' ? '男主角' : '女主角'}
                  </ThemedText>
                </View>
              </View>
              <TouchableOpacity onPress={() => setShowCharacterModal(false)}>
                <Feather name="x" size={22} color={theme.textPrimary} />
              </TouchableOpacity>
            </View>

            <ScrollView style={styles.characterModalBody}>
              <View style={styles.characterInfoRow}>
                <ThemedText variant="caption" color={theme.textMuted} style={styles.characterInfoLabel}>
                  年龄
                </ThemedText>
                <ThemedText variant="small" color={theme.textPrimary}>
                  {selectedCharacter?.age}岁
                </ThemedText>
              </View>

              <View style={styles.characterInfoRow}>
                <ThemedText variant="caption" color={theme.textMuted} style={styles.characterInfoLabel}>
                  职业
                </ThemedText>
                <ThemedText variant="small" color={theme.textPrimary}>
                  {selectedCharacter?.occupation}
                </ThemedText>
              </View>

              <View style={styles.characterInfoRow}>
                <ThemedText variant="caption" color={theme.textMuted} style={styles.characterInfoLabel}>
                  外貌
                </ThemedText>
                <ThemedText variant="small" color={theme.textPrimary}>
                  {selectedCharacter?.appearance || '暂无'}
                </ThemedText>
              </View>

              <View style={styles.characterInfoSection}>
                <ThemedText variant="caption" color={theme.textMuted} style={styles.characterInfoLabel}>
                  性格特点
                </ThemedText>
                <ThemedText variant="small" color={theme.textPrimary} style={styles.characterInfoValue}>
                  {selectedCharacter?.personality || '暂无'}
                </ThemedText>
              </View>

              <View style={styles.characterInfoSection}>
                <ThemedText variant="caption" color={theme.textMuted} style={styles.characterInfoLabel}>
                  背景故事
                </ThemedText>
                <ThemedText variant="small" color={theme.textPrimary} style={styles.characterInfoValue}>
                  {selectedCharacter?.background || '暂无'}
                </ThemedText>
              </View>

              {selectedCharacter?.traits && selectedCharacter.traits.length > 0 && (
                <View style={styles.characterInfoSection}>
                  <ThemedText variant="caption" color={theme.textMuted} style={styles.characterInfoLabel}>
                    人物标签
                  </ThemedText>
                  <View style={styles.traitsContainer}>
                    {selectedCharacter.traits.map((trait, index) => (
                      <View key={index} style={styles.traitTag}>
                        <ThemedText variant="caption" color="#C8102E">{trait}</ThemedText>
                      </View>
                    ))}
                  </View>
                </View>
              )}
            </ScrollView>

            <TouchableOpacity 
              style={styles.characterModalClose}
              onPress={() => setShowCharacterModal(false)}
            >
              <ThemedText variant="small" color="#C8102E">关闭</ThemedText>
            </TouchableOpacity>
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      {/* 格式设置弹窗 */}
      <Modal
        visible={showFormatModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowFormatModal(false)}
      >
        <TouchableOpacity 
          style={styles.formatModalOverlay}
          activeOpacity={1}
          onPress={() => setShowFormatModal(false)}
        >
          <TouchableOpacity 
            style={styles.formatModalContent}
            activeOpacity={1}
            onPress={() => {}}
          >
            <View style={styles.formatModalHeader}>
              <ThemedText variant="smallMedium" color={theme.textPrimary}>
                {formatModalType === 'font' && '选择字体'}
                {formatModalType === 'fontSize' && '选择字号'}
                {formatModalType === 'bold' && '加粗程度'}
                {formatModalType === 'highlight' && '标记线颜色'}
              </ThemedText>
              <TouchableOpacity onPress={() => setShowFormatModal(false)}>
                <Feather name="x" size={20} color={theme.textPrimary} />
              </TouchableOpacity>
            </View>

            {/* 字体选择 */}
            {formatModalType === 'font' && (
              <View style={styles.formatOptions}>
                {FONT_OPTIONS.map((font) => (
                  <TouchableOpacity
                    key={font}
                    style={[
                      styles.formatOption,
                      textFormat.fontFamily === font && styles.formatOptionActive,
                    ]}
                    onPress={() => setFontFamily(font)}
                  >
                    <ThemedText 
                      variant="small" 
                      color={textFormat.fontFamily === font ? '#C8102E' : theme.textPrimary}
                    >
                      {font}
                    </ThemedText>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {/* 字号选择 */}
            {formatModalType === 'fontSize' && (
              <View style={styles.formatOptions}>
                {FONT_SIZE_OPTIONS.map((size) => (
                  <TouchableOpacity
                    key={size}
                    style={[
                      styles.formatOption,
                      textFormat.fontSize === size && styles.formatOptionActive,
                    ]}
                    onPress={() => setFontSize(size)}
                  >
                    <ThemedText 
                      variant="small" 
                      color={textFormat.fontSize === size ? '#C8102E' : theme.textPrimary}
                    >
                      {size}
                    </ThemedText>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {/* 加粗档位选择 */}
            {formatModalType === 'bold' && (
              <View style={styles.formatOptions}>
                {BOLD_OPTIONS.map((option) => (
                  <TouchableOpacity
                    key={option.value}
                    style={[
                      styles.formatOption,
                      textFormat.boldLevel === option.value && styles.formatOptionActive,
                    ]}
                    onPress={() => setBoldLevel(option.value)}
                  >
                    <ThemedText 
                      variant="small" 
                      color={textFormat.boldLevel === option.value ? '#C8102E' : theme.textPrimary}
                      style={{ fontWeight: option.fontWeight }}
                    >
                      {option.label}
                    </ThemedText>
                  </TouchableOpacity>
                ))}
              </View>
            )}

            {/* 标记线颜色选择 */}
            {formatModalType === 'highlight' && (
              <View style={styles.formatOptions}>
                <TouchableOpacity
                  style={[styles.formatOption, !textFormat.highlightColor && styles.formatOptionActive]}
                  onPress={() => setHighlightColor(null)}
                >
                  <ThemedText variant="small" color={!textFormat.highlightColor ? '#C8102E' : theme.textPrimary}>
                    无
                  </ThemedText>
                </TouchableOpacity>
                {HIGHLIGHT_COLORS.map((color) => (
                  <TouchableOpacity
                    key={color.value}
                    style={[
                      styles.formatOption,
                      textFormat.highlightColor === color.value && styles.formatOptionActive,
                    ]}
                    onPress={() => setHighlightColor(color.value)}
                  >
                    <View style={[styles.colorPreview, { backgroundColor: color.value }]} />
                    <ThemedText 
                      variant="caption" 
                      color={textFormat.highlightColor === color.value ? '#C8102E' : theme.textPrimary}
                    >
                      {color.label}
                    </ThemedText>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </TouchableOpacity>
        </TouchableOpacity>
      </Modal>

      {/* 查找替换弹窗 */}
      <Modal
        visible={showSearchModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowSearchModal(false)}
      >
        <View style={styles.searchModalOverlay}>
          <View style={styles.searchModalContent}>
            <View style={styles.searchModalHeader}>
              <ThemedText variant="smallMedium" color={theme.textPrimary}>
                查找与替换
              </ThemedText>
              <TouchableOpacity onPress={() => setShowSearchModal(false)}>
                <Feather name="x" size={22} color={theme.textPrimary} />
              </TouchableOpacity>
            </View>

            {/* 搜索输入 */}
            <View style={styles.searchInputRow}>
              <View style={styles.searchInputWrap}>
                <Feather name="search" size={16} color={theme.textMuted} />
                <TextInput
                  style={styles.searchInput}
                  value={searchText}
                  onChangeText={(text) => {
                    setSearchText(text);
                    if (text.trim()) {
                      performSearch(text);
                    } else {
                      setSearchResults({ exact: [], synonyms: [] });
                    }
                  }}
                  placeholder="输入要查找的内容..."
                  placeholderTextColor={theme.textMuted}
                  returnKeyType="search"
                />
                {isSearching && <ActivityIndicator size="small" color="#C8102E" />}
              </View>
            </View>

            {/* 替换输入 */}
            <View style={styles.searchInputRow}>
              <View style={styles.searchInputWrap}>
                <Feather name="edit-2" size={16} color={theme.textMuted} />
                <TextInput
                  style={styles.searchInput}
                  value={replaceText}
                  onChangeText={setReplaceText}
                  placeholder="替换为..."
                  placeholderTextColor={theme.textMuted}
                />
              </View>
            </View>

            {/* 搜索结果 */}
            <ScrollView style={styles.searchResultsList}>
              {/* 精确匹配结果 */}
              {searchResults.exact.length > 0 && (
                <View style={styles.searchResultSection}>
                  <ThemedText variant="caption" color={theme.textMuted}>
                    精确匹配 ({searchResults.exact.length}处)
                  </ThemedText>
                  {searchResults.exact.map((result, idx) => {
                    // 获取上下文
                    const contextStart = Math.max(0, result.index - 10);
                    const contextEnd = Math.min(content.length, result.index + result.text.length + 10);
                    const beforeText = content.substring(contextStart, result.index);
                    const matchText = content.substring(result.index, result.index + result.text.length);
                    const afterText = content.substring(result.index + result.text.length, contextEnd);
                    
                    return (
                      <TouchableOpacity
                        key={`exact-${idx}`}
                        style={[
                          styles.searchResultItem,
                          currentSearchIndex === idx && styles.searchResultItemActive,
                        ]}
                        onPress={() => {
                          setCurrentSearchIndex(idx);
                          replaceSingle(result.index, result.text);
                        }}
                      >
                        <ThemedText variant="small" color={theme.textPrimary} numberOfLines={1}>
                          ...{beforeText}
                          <ThemedText variant="small" color="#C8102E" style={{ fontWeight: '600' }}>
                            {matchText}
                          </ThemedText>
                          {afterText}...
                        </ThemedText>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}

              {/* AI近义词匹配结果 */}
              {searchResults.synonyms.length > 0 && (
                <View style={styles.searchResultSection}>
                  <View style={styles.synonymSectionHeader}>
                    <ThemedText variant="caption" color={theme.textMuted}>
                      AI近义词匹配 ({searchResults.synonyms.length}处)
                    </ThemedText>
                    <View style={styles.aiTag}>
                      <ThemedText variant="caption" color="#FFFFFF">AI</ThemedText>
                    </View>
                  </View>
                  {searchResults.synonyms.map((result, idx) => {
                    const contextStart = Math.max(0, result.index - 10);
                    const contextEnd = Math.min(content.length, result.index + result.text.length + 10);
                    const beforeText = content.substring(contextStart, result.index);
                    const matchText = content.substring(result.index, result.index + result.text.length);
                    const afterText = content.substring(result.index + result.text.length, contextEnd);
                    
                    return (
                      <TouchableOpacity
                        key={`synonym-${idx}`}
                        style={styles.searchResultItem}
                        onPress={() => replaceSingle(result.index, result.text)}
                      >
                        <ThemedText variant="small" color={theme.textPrimary} numberOfLines={1}>
                          ...{beforeText}
                          <ThemedText variant="small" color="#8B5CF6" style={{ fontWeight: '600' }}>
                            {matchText}
                          </ThemedText>
                          {afterText}...
                        </ThemedText>
                        <ThemedText variant="caption" color="#8B5CF6" style={styles.synonymLabel}>
                          "{searchText}"的近义词: {result.synonym}
                        </ThemedText>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}

              {/* 无结果提示 */}
              {searchText && !isSearching && searchResults.exact.length === 0 && searchResults.synonyms.length === 0 && (
                <View style={styles.noResultContainer}>
                  <Feather name="search" size={32} color={theme.textMuted} />
                  <ThemedText variant="small" color={theme.textMuted} style={{ marginTop: 8 }}>
                    未找到相关内容
                  </ThemedText>
                </View>
              )}
            </ScrollView>

            {/* 操作按钮 */}
            <View style={styles.searchActions}>
              <TouchableOpacity
                style={[
                  styles.searchActionBtn,
                  (searchResults.exact.length === 0 && searchResults.synonyms.length === 0) && styles.searchActionBtnDisabled,
                ]}
                onPress={replaceAll}
                disabled={searchResults.exact.length === 0 && searchResults.synonyms.length === 0}
              >
                <Feather name="replace" size={16} color="#FFFFFF" />
                <ThemedText variant="small" color="#FFFFFF" style={{ marginLeft: 6 }}>
                  全部替换 ({searchResults.exact.length + searchResults.synonyms.length}处)
                </ThemedText>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* 悬浮球 */}
      <FloatingBall />
    </Screen>
  );
}
