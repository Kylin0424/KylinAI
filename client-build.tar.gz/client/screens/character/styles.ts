import { StyleSheet } from 'react-native';
import { Spacing, Theme } from '@/constants/theme';

export const createStyles = (theme: Theme) => {
  return StyleSheet.create({
    topBar: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: Spacing.md,
      paddingTop: Spacing.md,
      paddingBottom: Spacing.sm,
    },
    backButton: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: Spacing.xs,
      paddingHorizontal: Spacing.sm,
      backgroundColor: theme.backgroundTertiary,
      borderRadius: 6,
    },
    backText: {
      marginLeft: Spacing.xs,
    },
    scrollContent: {
      flexGrow: 1,
      paddingHorizontal: Spacing.md,
      paddingBottom: Spacing['2xl'],
    },
    header: {
      marginBottom: Spacing.md,
      alignItems: 'center',
    },
    decorativeLine: {
      width: 50,
      height: 2,
      backgroundColor: '#C8102E',
      marginBottom: Spacing.sm,
    },
    section: {
      marginBottom: Spacing.md,
    },
    sectionTitleContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: Spacing.sm,
    },
    labelIcon: {
      width: 28,
      height: 28,
      borderRadius: 6,
      backgroundColor: theme.backgroundTertiary,
      justifyContent: 'center',
      alignItems: 'center',
      marginRight: Spacing.sm,
    },
    sectionTitle: {
      fontWeight: '700',
      textTransform: 'uppercase',
      letterSpacing: 1,
      fontSize: 13,
    },
    inputGroup: {
      marginBottom: Spacing.sm,
    },
    inputRow: {
      flexDirection: 'row',
    },
    inputLabel: {
      marginBottom: 2,
      fontSize: 11,
    },
    textInput: {
      backgroundColor: theme.backgroundTertiary,
      borderRadius: 6,
      paddingHorizontal: Spacing.sm,
      paddingVertical: Spacing.xs,
      fontSize: 14,
      color: theme.textPrimary,
      borderWidth: 1,
      borderColor: theme.border,
    },
    occupationSelector: {
      backgroundColor: theme.backgroundTertiary,
      borderRadius: 6,
      paddingHorizontal: Spacing.sm,
      paddingVertical: Spacing.xs,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderWidth: 1,
      borderColor: theme.border,
    },
    // 下拉选择器
    dropdown: {
      backgroundColor: theme.backgroundTertiary,
      borderRadius: 6,
      paddingHorizontal: Spacing.sm,
      paddingVertical: Spacing.xs,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderWidth: 1,
      borderColor: theme.border,
      minHeight: 40,
    },
    // 家庭背景区域
    familyBackgroundSection: {
      marginTop: Spacing.sm,
    },
    // 成员人数列表项
    memberCountList: {
      marginTop: Spacing.sm,
    },
    memberCountItem: {
      paddingVertical: Spacing.sm,
      paddingHorizontal: Spacing.md,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: theme.border,
    },
    memberCountItemActive: {
      backgroundColor: theme.backgroundTertiary,
    },
    // 亲属关系列表项
    relationList: {
      marginTop: Spacing.sm,
    },
    relationItem: {
      paddingVertical: Spacing.sm,
      paddingHorizontal: Spacing.md,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: theme.border,
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    relationItemActive: {
      backgroundColor: theme.backgroundTertiary,
    },
    familyOptionsRow: {
      flexDirection: 'row',
      gap: 4,
    },
    familyOptionTab: {
      flex: 1,
      paddingVertical: Spacing.xs,
      paddingHorizontal: 2,
      borderRadius: 4,
      backgroundColor: theme.backgroundTertiary,
      alignItems: 'center',
      borderWidth: 1,
      borderColor: 'transparent',
    },
    familyOptionTabActive: {
      backgroundColor: theme.backgroundDefault,
      borderColor: '#C8102E',
    },
    familyOptionText: {
      fontSize: 11,
    },
    familyOptionValue: {
      fontWeight: '600',
    },
    sliderSection: {
      marginBottom: Spacing.sm,
    },
    sliderSectionTitle: {
      marginBottom: Spacing.xs,
      textTransform: 'uppercase',
      letterSpacing: 1,
      fontSize: 11,
    },
    sliderGroup: {
      marginBottom: Spacing.sm,
    },
    sliderHeader: {
      marginBottom: 2,
    },
    sliderLabels: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginTop: 1,
    },
    slider: {
      width: '100%',
      height: 32,
    },
    generateButton: {
      backgroundColor: '#1A1A1A',
      paddingVertical: Spacing.md,
      paddingHorizontal: Spacing.xl,
      borderRadius: 0,
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
    },
    generateButtonDisabled: {
      opacity: 0.6,
    },
    buttonText: {
      marginLeft: Spacing.sm,
      fontWeight: '700',
      textTransform: 'uppercase',
      letterSpacing: 1,
      fontSize: 13,
    },

    // Modal styles
    modalOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      justifyContent: 'flex-end',
    },
    modalContent: {
      backgroundColor: theme.backgroundRoot,
      borderTopLeftRadius: 20,
      borderTopRightRadius: 20,
      paddingHorizontal: Spacing.md,
      paddingBottom: Spacing.xl,
      maxHeight: '70%',
    },
    modalHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: Spacing.md,
      borderBottomWidth: StyleSheet.hairlineWidth,
      borderBottomColor: theme.border,
    },
    categoryTabs: {
      paddingVertical: Spacing.sm,
      maxHeight: 45,
    },
    categoryTab: {
      paddingVertical: Spacing.xs,
      paddingHorizontal: Spacing.sm,
      marginRight: Spacing.xs,
      borderRadius: 12,
      backgroundColor: theme.backgroundTertiary,
    },
    categoryTabActive: {
      backgroundColor: theme.backgroundDefault,
      borderWidth: 1,
      borderColor: '#C8102E',
    },
    occupationList: {
      marginTop: Spacing.sm,
    },
    occupationListContent: {
      paddingBottom: Spacing.md,
    },
    occupationItem: {
      flex: 1,
      margin: 2,
      paddingVertical: Spacing.xs,
      paddingHorizontal: Spacing.sm,
      backgroundColor: theme.backgroundTertiary,
      borderRadius: 6,
      alignItems: 'center',
    },
    occupationItemSelected: {
      backgroundColor: theme.backgroundDefault,
      borderWidth: 1,
      borderColor: '#C8102E',
    },
  });
};
