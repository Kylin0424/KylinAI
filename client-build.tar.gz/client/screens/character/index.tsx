import React, { useState, useMemo } from 'react';
import {
  ScrollView,
  TouchableOpacity,
  View,
  ActivityIndicator,
  TextInput,
  Modal,
  FlatList,
} from 'react-native';
import Slider from '@react-native-community/slider';
import { Feather } from '@expo/vector-icons';
import { useTheme } from '@/hooks/useTheme';
import { Screen } from '@/components/Screen';
import { ThemedText } from '@/components/ThemedText';
import { ThemedView } from '@/components/ThemedView';
import { useSafeRouter } from '@/hooks/useSafeRouter';
import { Spacing } from '@/constants/theme';
import { createStyles } from './styles';
import { OCCUPATION_CATEGORIES } from '@/constants/occupations';
import { FAMILY_RELATIONS, generateMemberCountOptions, getAllRelationsFlat } from '@/constants/familyRelations';

// 生成成员人数选项
const MEMBER_COUNT_OPTIONS = generateMemberCountOptions();
// 扁平化所有亲属关系
const ALL_RELATIONS = getAllRelationsFlat();

interface SliderConfig {
  key: string;
  label: string;
  minLabel: string;
  maxLabel: string;
  value: number;
}

export default function CharacterScreen() {
  const { theme, isDark } = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const router = useSafeRouter();

  const [isGenerating, setIsGenerating] = useState(false);

  // 手动输入的基本信息
  const [name, setName] = useState('');
  const [gender, setGender] = useState('');
  const [ageInput, setAgeInput] = useState('');
  const [heightInput, setHeightInput] = useState('');
  const [occupation, setOccupation] = useState('');

  // 家庭背景
  const [memberCount, setMemberCount] = useState<number>(1);
  const [familyRelation, setFamilyRelation] = useState<string>('');
  const [familyBackground, setFamilyBackground] = useState('');
  const [socialExperience, setSocialExperience] = useState('');

  // 职业选择弹窗
  const [showOccupationModal, setShowOccupationModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // 家庭成员弹窗
  const [showMemberCountModal, setShowMemberCountModal] = useState(false);
  const [showRelationModal, setShowRelationModal] = useState(false);

  // 滑块配置
  const [sliders, setSliders] = useState<SliderConfig[]>([
    // 性格维度
    { key: 'introversion', label: '性格倾向', minLabel: '内向', maxLabel: '外向', value: 50 },
    { key: 'rational', label: '思维方式', minLabel: '感性', maxLabel: '理性', value: 50 },
    { key: 'conservative', label: '生活态度', minLabel: '保守', maxLabel: '开放', value: 50 },
    { key: 'optimistic', label: '心态倾向', minLabel: '悲观', maxLabel: '乐观', value: 50 },
    // 能力维度
    { key: 'intelligence', label: '智慧程度', minLabel: '单纯', maxLabel: '睿智', value: 50 },
    { key: 'courage', label: '勇气指数', minLabel: '谨慎', maxLabel: '勇敢', value: 50 },
    { key: 'charisma', label: '魅力值', minLabel: '平凡', maxLabel: '迷人', value: 50 },
    { key: 'luck', label: '运气值', minLabel: '倒霉', maxLabel: '幸运', value: 50 },
    // 背景维度
    { key: 'socialStatus', label: '社会地位', minLabel: '底层', maxLabel: '上层', value: 50 },
    { key: 'wealth', label: '财富程度', minLabel: '贫困', maxLabel: '富裕', value: 50 },
  ]);

  const updateSlider = (key: string, value: number) => {
    setSliders(prev => prev.map(s => s.key === key ? { ...s, value } : s));
  };

  const handleGenerate = () => {
    if (!name.trim()) {
      return;
    }

    setIsGenerating(true);

    // 将滑块值和基本信息转换为参数
    const sliderValues: Record<string, number> = {};
    sliders.forEach(s => {
      sliderValues[s.key] = s.value;
    });

    router.push('/character-result', {
      sliders: JSON.stringify(sliderValues),
      name: name.trim(),
      gender: gender.trim() || '未设定',
      age: ageInput.trim() || '25',
      height: heightInput.trim() || '170cm',
      occupation: occupation.trim() || '未设定',
      memberCount: memberCount.toString(),
      familyRelation: familyRelation || '未设定',
      familyBackground: familyBackground.trim() || '未设定',
      socialExperience: socialExperience.trim() || '未设定',
    });

    setIsGenerating(false);
  };

  const handleSelectOccupation = (occ: string) => {
    setOccupation(occ);
    setShowOccupationModal(false);
  };

  const renderSlider = (slider: SliderConfig) => (
    <View key={slider.key} style={styles.sliderGroup}>
      <View style={styles.sliderHeader}>
        <ThemedText variant="smallMedium" color={theme.textPrimary}>
          {slider.label}
        </ThemedText>
        <View style={styles.sliderLabels}>
          <ThemedText variant="caption" color={theme.textMuted}>
            {slider.minLabel}
          </ThemedText>
          <ThemedText variant="caption" color={theme.textMuted}>
            {slider.maxLabel}
          </ThemedText>
        </View>
      </View>
      <Slider
        style={styles.slider}
        minimumValue={0}
        maximumValue={100}
        value={slider.value}
        onValueChange={(value) => updateSlider(slider.key, value)}
        minimumTrackTintColor="#C8102E"
        maximumTrackTintColor={theme.border}
        thumbTintColor="#C8102E"
      />
    </View>
  );

  return (
    <Screen backgroundColor={theme.backgroundRoot} statusBarStyle={isDark ? 'light' : 'dark'}>
      {/* Header with Back Button */}
      <View style={styles.topBar}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.push('/home')}>
          <Feather name="arrow-left" size={20} color={theme.textPrimary} />
          <ThemedText variant="small" color={theme.textPrimary} style={styles.backText}>
            返回首页
          </ThemedText>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Title */}
        <ThemedView level="root" style={styles.header}>
          <View style={styles.decorativeLine} />
          <ThemedText variant="h2" color={theme.textPrimary}>
            角色生成器
          </ThemedText>
          <ThemedText variant="caption" color={theme.textMuted}>
            调整参数，创造独特角色
          </ThemedText>
        </ThemedView>

        {/* Basic Info Section */}
        <ThemedView level="root" style={styles.section}>
          <View style={styles.sectionTitleContainer}>
            <View style={styles.labelIcon}>
              <Feather name="user" size={16} color={theme.textPrimary} />
            </View>
            <ThemedText variant="label" color={theme.textPrimary} style={styles.sectionTitle}>
              基本信息
            </ThemedText>
          </View>

          {/* Name Input */}
          <View style={styles.inputGroup}>
            <ThemedText variant="caption" color={theme.textMuted} style={styles.inputLabel}>
              姓名 *
            </ThemedText>
            <TextInput
              style={styles.textInput}
              placeholder="请输入角色姓名"
              placeholderTextColor={theme.textMuted}
              value={name}
              onChangeText={setName}
            />
          </View>

          {/* Gender Input */}
          <View style={styles.inputGroup}>
            <ThemedText variant="caption" color={theme.textMuted} style={styles.inputLabel}>
              性别
            </ThemedText>
            <TextInput
              style={styles.textInput}
              placeholder="男/女"
              placeholderTextColor={theme.textMuted}
              value={gender}
              onChangeText={setGender}
            />
          </View>

          {/* Age and Height Input */}
          <View style={styles.inputRow}>
            <View style={[styles.inputGroup, { flex: 1, marginRight: 8 }]}>
              <ThemedText variant="caption" color={theme.textMuted} style={styles.inputLabel}>
                年龄
              </ThemedText>
              <TextInput
                style={styles.textInput}
                placeholder="25"
                placeholderTextColor={theme.textMuted}
                value={ageInput}
                onChangeText={setAgeInput}
                keyboardType="numeric"
              />
            </View>
            <View style={[styles.inputGroup, { flex: 1, marginLeft: 8 }]}>
              <ThemedText variant="caption" color={theme.textMuted} style={styles.inputLabel}>
                身高
              </ThemedText>
              <TextInput
                style={styles.textInput}
                placeholder="170cm"
                placeholderTextColor={theme.textMuted}
                value={heightInput}
                onChangeText={setHeightInput}
              />
            </View>
          </View>

          {/* Occupation Selection */}
          <View style={styles.inputGroup}>
            <ThemedText variant="caption" color={theme.textMuted} style={styles.inputLabel}>
              职业
            </ThemedText>
            <TouchableOpacity
              style={styles.occupationSelector}
              onPress={() => setShowOccupationModal(true)}
            >
              <ThemedText
                variant="smallMedium"
                color={occupation ? theme.textPrimary : theme.textMuted}
              >
                {occupation || '选择职业...'}
              </ThemedText>
              <Feather name="chevron-down" size={20} color={theme.textMuted} />
            </TouchableOpacity>
          </View>

          {/* Family Background Section */}
          <View style={styles.familyBackgroundSection}>
            {/* 成员人数下拉 */}
            <ThemedText variant="caption" color={theme.textMuted} style={styles.inputLabel}>
              家庭成员人数
            </ThemedText>
            <TouchableOpacity
              style={styles.dropdown}
              onPress={() => setShowMemberCountModal(true)}
            >
              <ThemedText variant="body" color={theme.textPrimary}>
                {memberCount}人
              </ThemedText>
              <Feather name="chevron-down" size={20} color={theme.textMuted} />
            </TouchableOpacity>

            {/* 与我的关系下拉 */}
            <ThemedText variant="caption" color={theme.textMuted} style={[styles.inputLabel, { marginTop: Spacing.md }]}>
              与我的关系
            </ThemedText>
            <TouchableOpacity
              style={styles.dropdown}
              onPress={() => setShowRelationModal(true)}
            >
              <ThemedText variant="body" color={familyRelation ? theme.textPrimary : theme.textMuted}>
                {familyRelation || '请选择亲属关系'}
              </ThemedText>
              <Feather name="chevron-down" size={20} color={theme.textMuted} />
            </TouchableOpacity>

            {/* 家庭背景输入 */}
            <ThemedText variant="caption" color={theme.textMuted} style={[styles.inputLabel, { marginTop: Spacing.md }]}>
              家庭背景
            </ThemedText>
            <TextInput
              style={styles.textInput}
              placeholder="描述家庭的经济状况、社会地位等"
              placeholderTextColor={theme.textMuted}
              value={familyBackground}
              onChangeText={setFamilyBackground}
              multiline
              numberOfLines={3}
            />

            {/* 社会经历输入 */}
            <ThemedText variant="caption" color={theme.textMuted} style={[styles.inputLabel, { marginTop: Spacing.md }]}>
              社会经历
            </ThemedText>
            <TextInput
              style={styles.textInput}
              placeholder="描述重要的成长经历、教育背景等"
              placeholderTextColor={theme.textMuted}
              value={socialExperience}
              onChangeText={setSocialExperience}
              multiline
              numberOfLines={3}
            />
          </View>
        </ThemedView>

        {/* Sliders Section */}
        <ThemedView level="root" style={styles.section}>
          <View style={styles.sectionTitleContainer}>
            <View style={styles.labelIcon}>
              <Feather name="sliders" size={16} color={theme.textPrimary} />
            </View>
            <ThemedText variant="label" color={theme.textPrimary} style={styles.sectionTitle}>
              性格与背景
            </ThemedText>
          </View>

          {/* Personality Sliders */}
          <View style={styles.sliderSection}>
            <ThemedText variant="caption" color={theme.textMuted} style={styles.sliderSectionTitle}>
              性格维度
            </ThemedText>
            {sliders.slice(0, 4).map(renderSlider)}
          </View>

          {/* Ability Sliders */}
          <View style={styles.sliderSection}>
            <ThemedText variant="caption" color={theme.textMuted} style={styles.sliderSectionTitle}>
              能力维度
            </ThemedText>
            {sliders.slice(4, 8).map(renderSlider)}
          </View>

          {/* Background Sliders */}
          <View style={styles.sliderSection}>
            <ThemedText variant="caption" color={theme.textMuted} style={styles.sliderSectionTitle}>
              背景维度
            </ThemedText>
            {sliders.slice(8).map(renderSlider)}
          </View>
        </ThemedView>

        {/* Generate Button */}
        <TouchableOpacity
          style={[styles.generateButton, (!name.trim() || isGenerating) && styles.generateButtonDisabled]}
          onPress={handleGenerate}
          disabled={!name.trim() || isGenerating}
        >
          {isGenerating ? (
            <ActivityIndicator color={theme.buttonPrimaryText} />
          ) : (
            <>
              <Feather name="user-plus" size={20} color={theme.buttonPrimaryText} />
              <ThemedText variant="smallMedium" color={theme.buttonPrimaryText} style={styles.buttonText}>
                生成角色
              </ThemedText>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>

      {/* Occupation Selection Modal */}
      <Modal
        visible={showOccupationModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowOccupationModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <ThemedText variant="smallMedium" color={theme.textPrimary}>
                选择职业
              </ThemedText>
              <TouchableOpacity onPress={() => setShowOccupationModal(false)}>
                <Feather name="x" size={24} color={theme.textPrimary} />
              </TouchableOpacity>
            </View>

            {/* Category Tabs */}
            <View style={{ maxHeight: 50 }}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryTabs}>
                <TouchableOpacity
                  style={[styles.categoryTab, !selectedCategory && styles.categoryTabActive]}
                  onPress={() => setSelectedCategory(null)}
                >
                  <ThemedText
                    variant="small"
                    color={!selectedCategory ? '#C8102E' : theme.textMuted}
                  >
                    全部
                  </ThemedText>
                </TouchableOpacity>
                {OCCUPATION_CATEGORIES.map((cat) => (
                  <TouchableOpacity
                    key={cat.name}
                    style={[styles.categoryTab, selectedCategory === cat.name && styles.categoryTabActive]}
                    onPress={() => setSelectedCategory(cat.name)}
                  >
                    <ThemedText
                      variant="small"
                      color={selectedCategory === cat.name ? '#C8102E' : theme.textMuted}
                    >
                      {cat.name}
                    </ThemedText>
                  </TouchableOpacity>
                ))}
              </ScrollView>
            </View>

            {/* Occupation List */}
            <FlatList
              data={
                selectedCategory
                  ? OCCUPATION_CATEGORIES.find(c => c.name === selectedCategory)?.occupations || []
                  : OCCUPATION_CATEGORIES.flatMap(c => c.occupations)
              }
              keyExtractor={(item, index) => `${item}-${index}`}
              numColumns={2}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.occupationItem,
                    occupation === item && styles.occupationItemSelected,
                  ]}
                  onPress={() => handleSelectOccupation(item)}
                >
                  <ThemedText
                    variant="small"
                    color={occupation === item ? '#C8102E' : theme.textPrimary}
                    numberOfLines={1}
                  >
                    {item}
                  </ThemedText>
                </TouchableOpacity>
              )}
              style={styles.occupationList}
              contentContainerStyle={styles.occupationListContent}
            />
          </View>
        </View>
      </Modal>

      {/* Member Count Selection Modal */}
      <Modal
        visible={showMemberCountModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowMemberCountModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <ThemedText variant="smallMedium" color={theme.textPrimary}>
                选择家庭成员人数
              </ThemedText>
              <TouchableOpacity onPress={() => setShowMemberCountModal(false)}>
                <Feather name="x" size={24} color={theme.textPrimary} />
              </TouchableOpacity>
            </View>
            <FlatList
              data={MEMBER_COUNT_OPTIONS}
              keyExtractor={(item) => item.value.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.memberCountItem,
                    memberCount === item.value && styles.memberCountItemActive,
                  ]}
                  onPress={() => {
                    setMemberCount(item.value);
                    setShowMemberCountModal(false);
                  }}
                >
                  <ThemedText
                    variant="body"
                    color={memberCount === item.value ? '#C8102E' : theme.textPrimary}
                  >
                    {item.label}
                  </ThemedText>
                </TouchableOpacity>
              )}
              style={styles.memberCountList}
            />
          </View>
        </View>
      </Modal>

      {/* Family Relation Selection Modal */}
      <Modal
        visible={showRelationModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowRelationModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <ThemedText variant="smallMedium" color={theme.textPrimary}>
                选择亲属关系
              </ThemedText>
              <TouchableOpacity onPress={() => setShowRelationModal(false)}>
                <Feather name="x" size={24} color={theme.textPrimary} />
              </TouchableOpacity>
            </View>
            <FlatList
              data={ALL_RELATIONS}
              keyExtractor={(item, index) => `${item.category}-${item.relation}-${index}`}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={[
                    styles.relationItem,
                    familyRelation === item.relation && styles.relationItemActive,
                  ]}
                  onPress={() => {
                    setFamilyRelation(item.relation);
                    setShowRelationModal(false);
                  }}
                >
                  <ThemedText
                    variant="body"
                    color={familyRelation === item.relation ? '#C8102E' : theme.textPrimary}
                  >
                    {item.relation}
                  </ThemedText>
                  <ThemedText variant="caption" color={theme.textMuted}>
                    {item.category}
                  </ThemedText>
                </TouchableOpacity>
              )}
              style={styles.relationList}
            />
          </View>
        </View>
      </Modal>
    </Screen>
  );
}
