import React, { useState, useMemo, useCallback } from 'react';
import {
  ScrollView,
  View,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { Feather } from '@expo/vector-icons';
import { useTheme } from '@/hooks/useTheme';
import { Screen } from '@/components/Screen';
import { ThemedText } from '@/components/ThemedText';
import { useSafeRouter } from '@/hooks/useSafeRouter';
import { createStyles } from './styles';
import {
  Character,
  CharacterRelation,
  getAllCharacters,
  getAllRelations,
  deleteCharacter,
} from '@/utils/characterStorage';

export default function CharacterListScreen() {
  const { theme, isDark } = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const router = useSafeRouter();

  const [characters, setCharacters] = useState<Character[]>([]);
  const [relations, setRelations] = useState<CharacterRelation[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadData = async () => {
    setIsLoading(true);
    const chars = await getAllCharacters();
    const rels = await getAllRelations();
    setCharacters(chars);
    setRelations(rels);
    setIsLoading(false);
  };

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [])
  );

  const handleDeleteCharacter = (character: Character) => {
    Alert.alert(
      '确认删除',
      `确定要删除角色"${character.name}"吗？相关的角色关系也会被删除。`,
      [
        { text: '取消', style: 'cancel' },
        {
          text: '删除',
          style: 'destructive',
          onPress: async () => {
            await deleteCharacter(character.id);
            loadData();
          },
        },
      ]
    );
  };

  const getCharacterRelations = (charId: string): CharacterRelation[] => {
    return relations.filter(
      r => r.characterId === charId || r.relatedCharacterId === charId
    );
  };

  const getRelationLabel = (relation: CharacterRelation, charId: string): string => {
    const relationTypes: Record<string, string> = {
      'father': '父亲',
      'mother': '母亲',
      'spouse': '配偶',
      'sibling': '兄弟姐妹',
      'child': '子女',
      'friend': '朋友',
      'enemy': '敌人',
      'colleague': '同事',
      'lover': '恋人',
      'mentor': '导师',
      'student': '学生',
    };
    
    const label = relationTypes[relation.relationType] || relation.relationType;
    return label;
  };

  const getRelatedCharacter = (relation: CharacterRelation, charId: string): Character | undefined => {
    const relatedId = relation.characterId === charId 
      ? relation.relatedCharacterId 
      : relation.characterId;
    return characters.find(c => c.id === relatedId);
  };

  return (
    <Screen backgroundColor={theme.backgroundRoot} statusBarStyle={isDark ? 'light' : 'dark'}>
      {/* Header with Back Button */}
      <View style={styles.topBar}>
        <TouchableOpacity style={styles.backButton} onPress={() => router.push('/home')}>
          <Feather name="arrow-left" size={20} color={theme.textPrimary} />
          <ThemedText variant="small" color={theme.textPrimary} style={styles.backText}>
            返回首页
          </ThemedText>
        </TouchableOpacity>
        <TouchableOpacity style={styles.addButton} onPress={() => router.push('/character')}>
          <Feather name="plus" size={20} color="#C8102E" />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.decorativeLine} />
          <ThemedText variant="h2" color={theme.textPrimary} style={styles.title}>
            角色库
          </ThemedText>
          <ThemedText variant="caption" color={theme.textMuted} style={styles.subtitle}>
            共 {characters.length} 个角色
          </ThemedText>
        </View>

        {isLoading ? (
          <View style={styles.emptyContainer}>
            <ThemedText variant="body" color={theme.textMuted}>
              加载中...
            </ThemedText>
          </View>
        ) : characters.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Feather name="users" size={48} color={theme.textMuted} />
            <ThemedText variant="body" color={theme.textMuted} style={styles.emptyText}>
              还没有创建任何角色
            </ThemedText>
            <TouchableOpacity style={styles.createButton} onPress={() => router.push('/character')}>
              <Feather name="user-plus" size={20} color={theme.buttonPrimaryText} />
              <ThemedText variant="smallMedium" color={theme.buttonPrimaryText} style={styles.createButtonText}>
                创建角色
              </ThemedText>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.characterList}>
            {characters.map(char => {
              const charRelations = getCharacterRelations(char.id);
              return (
                <View key={char.id} style={styles.characterCard}>
                  <View style={styles.characterHeader}>
                    <View style={styles.characterMain}>
                      <ThemedText variant="h3" color={theme.textPrimary}>
                        {char.name}
                      </ThemedText>
                      <ThemedText variant="caption" color={theme.textMuted}>
                        {char.gender} · {char.age}岁 · {char.occupation}
                      </ThemedText>
                    </View>
                    <TouchableOpacity
                      style={styles.deleteButton}
                      onPress={() => handleDeleteCharacter(char)}
                    >
                      <Feather name="trash-2" size={16} color="#C8102E" />
                    </TouchableOpacity>
                  </View>

                  {charRelations.length > 0 && (
                    <View style={styles.relationsContainer}>
                      <ThemedText variant="caption" color={theme.textMuted} style={styles.relationsTitle}>
                        关系
                      </ThemedText>
                      <View style={styles.relationsList}>
                        {charRelations.map(relation => {
                          const relatedChar = getRelatedCharacter(relation, char.id);
                          return (
                            <View key={relation.id} style={styles.relationTag}>
                              <ThemedText variant="caption" color={theme.textSecondary}>
                                {getRelationLabel(relation, char.id)}: {relatedChar?.name || '未知'}
                              </ThemedText>
                            </View>
                          );
                        })}
                      </View>
                    </View>
                  )}

                  <TouchableOpacity
                    style={styles.viewDetailButton}
                    onPress={() => {
                      // 可以跳转到角色详情页查看完整信息
                      Alert.alert('提示', '角色详情功能开发中');
                    }}
                  >
                    <ThemedText variant="small" color="#C8102E">
                      查看详情
                    </ThemedText>
                    <Feather name="chevron-right" size={16} color="#C8102E" />
                  </TouchableOpacity>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>
    </Screen>
  );
}
