import { StyleSheet } from 'react-native';
import { Spacing, Theme } from '@/constants/theme';

export const createStyles = (theme: Theme) => {
  return StyleSheet.create({
    topBar: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: Spacing.lg,
      paddingTop: Spacing.lg,
      paddingBottom: Spacing.md,
    },
    backButton: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: Spacing.sm,
      paddingHorizontal: Spacing.md,
      backgroundColor: theme.backgroundTertiary,
      borderRadius: 8,
    },
    backText: {
      marginLeft: Spacing.sm,
    },
    addButton: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: theme.backgroundTertiary,
      justifyContent: 'center',
      alignItems: 'center',
    },
    scrollContent: {
      flexGrow: 1,
      paddingHorizontal: Spacing.lg,
      paddingBottom: Spacing['5xl'],
    },
    header: {
      marginBottom: Spacing.xl,
      alignItems: 'center',
    },
    decorativeLine: {
      width: 60,
      height: 2,
      backgroundColor: '#C8102E',
      marginBottom: Spacing.lg,
    },
    title: {
      fontSize: 28,
      fontWeight: '900',
      letterSpacing: -0.5,
      textAlign: 'center',
    },
    subtitle: {
      marginTop: Spacing.sm,
    },
    emptyContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: 400,
    },
    emptyText: {
      marginTop: Spacing.lg,
    },
    createButton: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#1A1A1A',
      paddingHorizontal: Spacing['2xl'],
      paddingVertical: Spacing.lg,
      marginTop: Spacing.xl,
    },
    createButtonText: {
      marginLeft: Spacing.md,
    },
    characterList: {
      gap: Spacing.md,
    },
    characterCard: {
      backgroundColor: '#FFFFFF',
      padding: Spacing.lg,
    },
    characterHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'flex-start',
      marginBottom: Spacing.md,
    },
    characterMain: {
      flex: 1,
    },
    deleteButton: {
      padding: Spacing.sm,
    },
    relationsContainer: {
      borderTopWidth: StyleSheet.hairlineWidth,
      borderTopColor: '#E5E5E5',
      paddingTop: Spacing.md,
      marginBottom: Spacing.md,
    },
    relationsTitle: {
      marginBottom: Spacing.sm,
    },
    relationsList: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: Spacing.sm,
    },
    relationTag: {
      backgroundColor: theme.backgroundTertiary,
      paddingHorizontal: Spacing.md,
      paddingVertical: Spacing.xs,
      borderRadius: 4,
    },
    viewDetailButton: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderTopWidth: StyleSheet.hairlineWidth,
      borderTopColor: '#E5E5E5',
      paddingTop: Spacing.md,
    },
  });
};
