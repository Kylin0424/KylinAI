import React, { useState, useMemo } from 'react';
import {
  ScrollView,
  View,
  TouchableOpacity,
  ActivityIndicator,
  TextInput,
  Alert,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useTheme } from '@/hooks/useTheme';
import { Screen } from '@/components/Screen';
import { ThemedText } from '@/components/ThemedText';
import { useSafeRouter, useSafeSearchParams } from '@/hooks/useSafeRouter';
import { useFocusEffect } from 'expo-router';
import { createStyles } from './styles';
import {
  Character,
  getCharacterById,
  updateCharacter,
  deleteCharacter,
} from '@/utils/characterStorage';
import { getNovelById, Novel } from '@/utils/novelStorage';

export default function CharacterDetailScreen() {
  const { theme, isDark } = useTheme();
  const styles = useMemo(() => createStyles(theme), [theme]);
  const router = useSafeRouter();

  const params = useSafeSearchParams<{
    characterId: string;
  }>();

  const [character, setCharacter] = useState<Character | null>(null);
  const [novel, setNovel] = useState<Novel | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // 编辑表单状态
  const [editForm, setEditForm] = useState({
    name: '',
    gender: '',
    age: '',
    height: '',
    occupation: '',
    personality: '',
    experience: '',
    familyBackground: '',
    appearance: '',
    specialTraits: '',
  });

  useFocusEffect(
    React.useCallback(() => {
      const loadCharacterData = async () => {
        if (!params.characterId) return;
        setIsLoading(true);
        const char = await getCharacterById(params.characterId);
        setCharacter(char);
        if (char) {
          // 初始化编辑表单
          setEditForm({
            name: char.name,
            gender: char.gender,
            age: char.age.toString(),
            height: char.height,
            occupation: char.occupation,
            personality: char.personality,
            experience: char.experience,
            familyBackground: char.familyBackground,
            appearance: char.appearance,
            specialTraits: char.specialTraits,
          });

          if (char.novelId) {
            const n = await getNovelById(char.novelId);
            setNovel(n);
          }
        }
        setIsLoading(false);
      };
      loadCharacterData();
    }, [params.characterId])
  );

  // 检查是否可编辑（未关联小说的角色可编辑）
  const canEdit = !character?.novelId;

  const handleStartEdit = () => {
    if (!canEdit) {
      Alert.alert('提示', '该角色已用于小说创作，为保持角色一致性，禁止编辑');
      return;
    }
    setIsEditing(true);
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    // 重置表单
    if (character) {
      setEditForm({
        name: character.name,
        gender: character.gender,
        age: character.age.toString(),
        height: character.height,
        occupation: character.occupation,
        personality: character.personality,
        experience: character.experience,
        familyBackground: character.familyBackground,
        appearance: character.appearance,
        specialTraits: character.specialTraits,
      });
    }
  };

  const handleSaveEdit = async () => {
    if (!character || !editForm.name.trim()) {
      Alert.alert('提示', '姓名不能为空');
      return;
    }

    setIsSaving(true);
    try {
      const updatedCharacter: Character = {
        ...character,
        name: editForm.name.trim(),
        gender: editForm.gender,
        age: parseInt(editForm.age) || character.age,
        height: editForm.height,
        occupation: editForm.occupation,
        personality: editForm.personality,
        experience: editForm.experience,
        familyBackground: editForm.familyBackground,
        appearance: editForm.appearance,
        specialTraits: editForm.specialTraits,
      };

      await updateCharacter(updatedCharacter);
      setCharacter(updatedCharacter);
      setIsEditing(false);
      Alert.alert('成功', '角色信息已更新');
    } catch (error) {
      console.error('Error updating character:', error);
      Alert.alert('错误', '保存失败，请重试');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = () => {
    if (!character) return;

    if (!canEdit) {
      Alert.alert('提示', '该角色已用于小说创作，无法删除');
      return;
    }

    Alert.alert(
      '确认删除',
      `确定要删除角色"${character.name}"吗？`,
      [
        { text: '取消', style: 'cancel' },
        {
          text: '删除',
          style: 'destructive',
          onPress: async () => {
            await deleteCharacter(character.id);
            router.back();
          },
        },
      ]
    );
  };

  if (isLoading) {
    return (
      <Screen backgroundColor={theme.backgroundRoot} statusBarStyle={isDark ? 'light' : 'dark'}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#C8102E" />
        </View>
      </Screen>
    );
  }

  if (!character) {
    return (
      <Screen backgroundColor={theme.backgroundRoot} statusBarStyle={isDark ? 'light' : 'dark'}>
        <View style={styles.errorContainer}>
          <Feather name="alert-circle" size={48} color={theme.textMuted} />
          <ThemedText variant="small" color={theme.textMuted} style={{ marginTop: 12 }}>
            角色不存在
          </ThemedText>
          <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
            <ThemedText variant="smallMedium" color="#C8102E">返回</ThemedText>
          </TouchableOpacity>
        </View>
      </Screen>
    );
  }

  return (
    <Screen backgroundColor={theme.backgroundRoot} statusBarStyle={isDark ? 'light' : 'dark'}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.headerBackButton} onPress={() => router.push('/home')}>
          <Feather name="arrow-left" size={20} color={theme.textPrimary} />
          <ThemedText variant="small" color={theme.textPrimary} style={styles.backText}>
            返回首页
          </ThemedText>
        </TouchableOpacity>
        {!isEditing && (
          <TouchableOpacity style={styles.editButton} onPress={handleStartEdit}>
            <Feather name="edit-2" size={18} color={canEdit ? '#C8102E' : theme.textMuted} />
          </TouchableOpacity>
        )}
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* 角色基本信息 */}
        <View style={styles.characterHeader}>
          <View style={styles.characterAvatar}>
            <ThemedText variant="h2" color="#C8102E">
              {character.name.charAt(0)}
            </ThemedText>
          </View>
          {isEditing ? (
            <TextInput
              style={styles.nameInput}
              value={editForm.name}
              onChangeText={(text) => setEditForm({ ...editForm, name: text })}
              placeholder="角色姓名"
              placeholderTextColor={theme.textMuted}
            />
          ) : (
            <ThemedText variant="h2" color={theme.textPrimary} style={styles.characterName}>
              {character.name}
            </ThemedText>
          )}
          {!isEditing && (
            <ThemedText variant="small" color={theme.textMuted}>
              {character.occupation}
            </ThemedText>
          )}
        </View>

        {/* 基本信息卡片 */}
        <View style={styles.infoCard}>
          <View style={styles.infoRow}>
            <View style={styles.infoItem}>
              <ThemedText variant="caption" color={theme.textMuted}>性别</ThemedText>
              {isEditing ? (
                <TextInput
                  style={styles.infoInput}
                  value={editForm.gender}
                  onChangeText={(text) => setEditForm({ ...editForm, gender: text })}
                  placeholder="男/女"
                  placeholderTextColor={theme.textMuted}
                />
              ) : (
                <ThemedText variant="smallMedium" color={theme.textPrimary}>{character.gender}</ThemedText>
              )}
            </View>
            <View style={styles.infoItem}>
              <ThemedText variant="caption" color={theme.textMuted}>年龄</ThemedText>
              {isEditing ? (
                <TextInput
                  style={styles.infoInput}
                  value={editForm.age}
                  onChangeText={(text) => setEditForm({ ...editForm, age: text })}
                  placeholder="年龄"
                  placeholderTextColor={theme.textMuted}
                  keyboardType="numeric"
                />
              ) : (
                <ThemedText variant="smallMedium" color={theme.textPrimary}>{character.age}岁</ThemedText>
              )}
            </View>
            <View style={styles.infoItem}>
              <ThemedText variant="caption" color={theme.textMuted}>身高</ThemedText>
              {isEditing ? (
                <TextInput
                  style={styles.infoInput}
                  value={editForm.height}
                  onChangeText={(text) => setEditForm({ ...editForm, height: text })}
                  placeholder="身高"
                  placeholderTextColor={theme.textMuted}
                />
              ) : (
                <ThemedText variant="smallMedium" color={theme.textPrimary}>{character.height}</ThemedText>
              )}
            </View>
          </View>
          {isEditing && (
            <View style={styles.infoItemFull}>
              <ThemedText variant="caption" color={theme.textMuted}>职业</ThemedText>
              <TextInput
                style={styles.infoInput}
                value={editForm.occupation}
                onChangeText={(text) => setEditForm({ ...editForm, occupation: text })}
                placeholder="职业"
                placeholderTextColor={theme.textMuted}
              />
            </View>
          )}
        </View>

        {/* 所属小说提示 */}
        {novel && (
          <View style={styles.lockedNotice}>
            <Feather name="lock" size={14} color={theme.textMuted} />
            <ThemedText variant="caption" color={theme.textMuted}>
              该角色已用于小说《{novel.title}》，为保持一致性禁止编辑
            </ThemedText>
          </View>
        )}

        {/* 详细信息编辑区域 */}
        {isEditing ? (
          <>
            <View style={styles.section}>
              <ThemedText variant="smallMedium" color={theme.textPrimary} style={styles.sectionTitle}>性格特点</ThemedText>
              <TextInput
                style={styles.textArea}
                value={editForm.personality}
                onChangeText={(text) => setEditForm({ ...editForm, personality: text })}
                placeholder="描述性格特点..."
                placeholderTextColor={theme.textMuted}
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.section}>
              <ThemedText variant="smallMedium" color={theme.textPrimary} style={styles.sectionTitle}>外貌描述</ThemedText>
              <TextInput
                style={styles.textArea}
                value={editForm.appearance}
                onChangeText={(text) => setEditForm({ ...editForm, appearance: text })}
                placeholder="描述外貌特征..."
                placeholderTextColor={theme.textMuted}
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.section}>
              <ThemedText variant="smallMedium" color={theme.textPrimary} style={styles.sectionTitle}>人生经历</ThemedText>
              <TextInput
                style={styles.textArea}
                value={editForm.experience}
                onChangeText={(text) => setEditForm({ ...editForm, experience: text })}
                placeholder="描述人生经历..."
                placeholderTextColor={theme.textMuted}
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.section}>
              <ThemedText variant="smallMedium" color={theme.textPrimary} style={styles.sectionTitle}>家庭背景</ThemedText>
              <TextInput
                style={styles.textArea}
                value={editForm.familyBackground}
                onChangeText={(text) => setEditForm({ ...editForm, familyBackground: text })}
                placeholder="描述家庭背景..."
                placeholderTextColor={theme.textMuted}
                multiline
                numberOfLines={4}
              />
            </View>

            <View style={styles.section}>
              <ThemedText variant="smallMedium" color={theme.textPrimary} style={styles.sectionTitle}>特殊特征</ThemedText>
              <TextInput
                style={styles.textArea}
                value={editForm.specialTraits}
                onChangeText={(text) => setEditForm({ ...editForm, specialTraits: text })}
                placeholder="描述特殊特征..."
                placeholderTextColor={theme.textMuted}
                multiline
                numberOfLines={3}
              />
            </View>

            {/* 编辑操作按钮 */}
            <View style={styles.editActions}>
              <TouchableOpacity style={styles.cancelButton} onPress={handleCancelEdit}>
                <ThemedText variant="smallMedium" color={theme.textPrimary}>取消</ThemedText>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.saveButton, isSaving && styles.saveButtonDisabled]}
                onPress={handleSaveEdit}
                disabled={isSaving}
              >
                {isSaving ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <ThemedText variant="smallMedium" color="#FFFFFF">保存</ThemedText>
                )}
              </TouchableOpacity>
            </View>
          </>
        ) : (
          <>
            {/* 性格特点 */}
            {character.personality && (
              <View style={styles.section}>
                <View style={styles.sectionHeader}>
                  <View style={styles.labelIcon}>
                    <Feather name="heart" size={14} color={theme.textPrimary} />
                  </View>
                  <ThemedText variant="smallMedium" color={theme.textPrimary}>性格特点</ThemedText>
                </View>
                <View style={styles.contentCard}>
                  <ThemedText variant="small" color={theme.textSecondary}>{character.personality}</ThemedText>
                </View>
              </View>
            )}

            {/* 外貌描述 */}
            {character.appearance && (
              <View style={styles.section}>
                <View style={styles.sectionHeader}>
                  <View style={styles.labelIcon}>
                    <Feather name="eye" size={14} color={theme.textPrimary} />
                  </View>
                  <ThemedText variant="smallMedium" color={theme.textPrimary}>外貌描述</ThemedText>
                </View>
                <View style={styles.contentCard}>
                  <ThemedText variant="small" color={theme.textSecondary}>{character.appearance}</ThemedText>
                </View>
              </View>
            )}

            {/* 人生经历 */}
            {character.experience && (
              <View style={styles.section}>
                <View style={styles.sectionHeader}>
                  <View style={styles.labelIcon}>
                    <Feather name="briefcase" size={14} color={theme.textPrimary} />
                  </View>
                  <ThemedText variant="smallMedium" color={theme.textPrimary}>人生经历</ThemedText>
                </View>
                <View style={styles.contentCard}>
                  <ThemedText variant="small" color={theme.textSecondary}>{character.experience}</ThemedText>
                </View>
              </View>
            )}

            {/* 家庭背景 */}
            {character.familyBackground && (
              <View style={styles.section}>
                <View style={styles.sectionHeader}>
                  <View style={styles.labelIcon}>
                    <Feather name="home" size={14} color={theme.textPrimary} />
                  </View>
                  <ThemedText variant="smallMedium" color={theme.textPrimary}>家庭背景</ThemedText>
                </View>
                <View style={styles.contentCard}>
                  <ThemedText variant="small" color={theme.textSecondary}>{character.familyBackground}</ThemedText>
                </View>
              </View>
            )}

            {/* 特殊特征 */}
            {character.specialTraits && (
              <View style={styles.section}>
                <View style={styles.sectionHeader}>
                  <View style={styles.labelIcon}>
                    <Feather name="star" size={14} color={theme.textPrimary} />
                  </View>
                  <ThemedText variant="smallMedium" color={theme.textPrimary}>特殊特征</ThemedText>
                </View>
                <View style={styles.contentCard}>
                  <ThemedText variant="small" color={theme.textSecondary}>{character.specialTraits}</ThemedText>
                </View>
              </View>
            )}

            {/* 删除按钮 */}
            {canEdit && (
              <TouchableOpacity style={styles.deleteButton} onPress={handleDelete}>
                <Feather name="trash-2" size={16} color="#C8102E" />
                <ThemedText variant="small" color="#C8102E" style={{ marginLeft: 6 }}>
                  删除角色
                </ThemedText>
              </TouchableOpacity>
            )}
          </>
        )}
      </ScrollView>
    </Screen>
  );
}
