import React, { useState, useRef, useCallback } from 'react';
import {
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
  Animated,
  PanResponder,
  Dimensions,
  Linking,
  Alert,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useTheme } from '@/hooks/useTheme';
import { useSafeRouter } from '@/hooks/useSafeRouter';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const BALL_SIZE = 32;
const MENU_ITEM_SIZE = 40;
const MENU_RADIUS = 70;

interface MenuItem {
  id: string;
  icon: string;
  label: string;
  color: string;
  action: () => void;
}

interface FloatingBallProps {
  onNavigate?: (screen: string) => void;
}

export const FloatingBall: React.FC<FloatingBallProps> = ({ onNavigate }) => {
  const { theme, isDark } = useTheme();
  const router = useSafeRouter();
  const [isExpanded, setIsExpanded] = useState(false);

  // 悬浮球位置
  const position = useRef(new Animated.ValueXY({
    x: SCREEN_WIDTH - BALL_SIZE - 12,
    y: SCREEN_HEIGHT / 2,
  })).current;

  // 菜单旋转角度（用户可控制）
  const menuRotation = useRef(new Animated.Value(0)).current;

  // 菜单项展开动画
  const menuAnimations = useRef(
    Array.from({ length: 8 }, () => ({
      scale: new Animated.Value(0),
      opacity: new Animated.Value(0),
    }))
  ).current;

  // 展开时的中心位置
  const [centerPosition, setCenterPosition] = useState({ x: 0, y: 0 });

  // 菜单项配置
  const getMenuItems = useCallback((): MenuItem[] => [
    {
      id: 'character-list',
      icon: 'users',
      label: '角色库',
      color: '#4F46E5',
      action: () => {
        setIsExpanded(false);
        resetMenuAnimations();
        router.push('/character-list');
      },
    },
    {
      id: 'character',
      icon: 'user-plus',
      label: '生成角色',
      color: '#059669',
      action: () => {
        setIsExpanded(false);
        resetMenuAnimations();
        router.push('/character');
      },
    },
    {
      id: 'ai-search',
      icon: 'search',
      label: 'AI查询',
      color: '#C8102E',
      action: () => {
        setIsExpanded(false);
        resetMenuAnimations();
        Alert.alert('AI智能查询', 'AI资料查询功能开发中，敬请期待');
      },
    },
    {
      id: 'gallery',
      icon: 'image',
      label: '相册',
      color: '#EA580C',
      action: () => {
        setIsExpanded(false);
        resetMenuAnimations();
        Alert.alert('相册', '手机相册功能开发中，敬请期待');
      },
    },
    {
      id: 'bookmark',
      icon: 'bookmark',
      label: '收藏',
      color: '#7C3AED',
      action: () => {
        setIsExpanded(false);
        resetMenuAnimations();
        Alert.alert('收藏', '收藏功能开发中，敬请期待');
      },
    },
    {
      id: 'settings',
      icon: 'settings',
      label: '设置',
      color: '#64748B',
      action: () => {
        setIsExpanded(false);
        resetMenuAnimations();
        Alert.alert('设置', '设置功能开发中，敬请期待');
      },
    },
    {
      id: 'help',
      icon: 'help-circle',
      label: '帮助',
      color: '#0EA5E9',
      action: () => {
        setIsExpanded(false);
        resetMenuAnimations();
        Linking.openURL('https://help.example.com');
      },
    },
    {
      id: 'feedback',
      icon: 'message-circle',
      label: '反馈',
      color: '#F43F5E',
      action: () => {
        setIsExpanded(false);
        resetMenuAnimations();
        Linking.openURL('mailto:feedback@example.com');
      },
    },
  ], [router]);

  // 重置菜单动画
  const resetMenuAnimations = () => {
    menuAnimations.forEach(anim => {
      anim.scale.setValue(0);
      anim.opacity.setValue(0);
    });
    menuRotation.setValue(0);
  };

  // 展开/收起菜单
  const toggleMenu = useCallback(() => {
    if (isExpanded) {
      // 收起动画
      Animated.parallel([
        ...menuAnimations.map(anim =>
          Animated.parallel([
            Animated.spring(anim.scale, {
              toValue: 0,
              useNativeDriver: true,
              tension: 300,
              friction: 20,
            }),
            Animated.timing(anim.opacity, {
              toValue: 0,
              duration: 150,
              useNativeDriver: true,
            }),
          ])
        ),
      ]).start();
      setTimeout(() => {
        setIsExpanded(false);
        resetMenuAnimations();
      }, 200);
    } else {
      // 展开动画
      setIsExpanded(true);
      
      // 记录当前位置作为中心
      const currentX = (position.x as any).__getValue ? (position.x as any).__getValue() : SCREEN_WIDTH - BALL_SIZE - 12;
      const currentY = (position.y as any).__getValue ? (position.y as any).__getValue() : SCREEN_HEIGHT / 2;
      setCenterPosition({ x: currentX + BALL_SIZE / 2, y: currentY + BALL_SIZE / 2 });

      // 重置动画值
      menuAnimations.forEach(anim => {
        anim.scale.setValue(0);
        anim.opacity.setValue(0);
      });
      menuRotation.setValue(0);

      // 执行弹出动画
      Animated.parallel([
        ...menuAnimations.map((anim, index) =>
          Animated.sequence([
            Animated.delay(index * 40),
            Animated.parallel([
              Animated.spring(anim.scale, {
                toValue: 1,
                useNativeDriver: true,
                tension: 300,
                friction: 20,
              }),
              Animated.timing(anim.opacity, {
                toValue: 1,
                duration: 200,
                useNativeDriver: true,
              }),
            ]),
          ])
        ),
      ]).start();
    }
  }, [isExpanded, menuAnimations, menuRotation, position]);

  // 旋转手势处理
  const rotationResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => isExpanded,
      onMoveShouldSetPanResponder: () => isExpanded,
      onPanResponderGrant: (evt) => {
        // 记录起始角度
      },
      onPanResponderMove: (evt, gestureState) => {
        if (!isExpanded) return;
        
        // 计算当前触摸点相对于中心的角度
        const dx = evt.nativeEvent.locationX - MENU_RADIUS;
        const dy = evt.nativeEvent.locationY - MENU_RADIUS;
        const angle = Math.atan2(dy, dx) * (180 / Math.PI);
        
        // 更新旋转角度
        menuRotation.setValue(angle);
      },
      onPanResponderRelease: () => {
        // 保持当前角度
      },
    })
  ).current;

  // 悬浮球拖拽手势
  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => !isExpanded,
      onPanResponderGrant: () => {
        if (!isExpanded) {
          position.setOffset({
            x: (position.x as any)._value || 0,
            y: (position.y as any)._value || 0,
          });
          position.setValue({ x: 0, y: 0 });
        }
      },
      onPanResponderMove: (evt, gestureState) => {
        if (!isExpanded) {
          Animated.event(
            [null, { dx: position.x, dy: position.y }],
            { useNativeDriver: false }
          )(evt, gestureState);
        }
      },
      onPanResponderRelease: (_, gesture) => {
        if (isExpanded) return;
        
        position.flattenOffset();

        if (Math.abs(gesture.dx) < 5 && Math.abs(gesture.dy) < 5) {
          toggleMenu();
        } else {
          Animated.spring(position.x, {
            toValue: (position.x as any)._value > SCREEN_WIDTH / 2
              ? SCREEN_WIDTH - BALL_SIZE - 12
              : 12,
            useNativeDriver: false,
            tension: 100,
            friction: 10,
          }).start();
        }
      },
    })
  ).current;

  const menuItems = getMenuItems();

  // 渲染菜单项
  const renderMenuItem = (item: MenuItem, index: number) => {
    const anim = menuAnimations[index];
    const baseAngle = (index * 45 - 90) * (Math.PI / 180);

    return (
      <Animated.View
        key={item.id}
        style={[
          styles.menuItemContainer,
          {
            transform: [
              {
                translateX: anim.scale.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, Math.cos(baseAngle) * MENU_RADIUS],
                }),
              },
              {
                translateY: anim.scale.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0, Math.sin(baseAngle) * MENU_RADIUS],
                }),
              },
              { scale: anim.scale },
            ],
            opacity: anim.opacity,
          },
        ]}
      >
        <TouchableOpacity
          style={styles.menuItem}
          onPress={item.action}
          activeOpacity={0.8}
        >
          <View style={[styles.menuIconWrap, { backgroundColor: item.color + '15' }]}>
            <Feather name={item.icon as any} size={16} color={item.color} />
          </View>
        </TouchableOpacity>
        <Text style={styles.menuItemLabel}>{item.label}</Text>
      </Animated.View>
    );
  };

  return (
    <>
      {isExpanded && (
        <TouchableOpacity
          style={styles.overlay}
          activeOpacity={1}
          onPress={() => {
            setIsExpanded(false);
            resetMenuAnimations();
          }}
        />
      )}

      <Animated.View
        style={[
          styles.container,
          {
            transform: position.getTranslateTransform(),
          },
        ]}
        {...(isExpanded ? {} : panResponder.panHandlers)}
      >
        {/* 菜单项容器 - 用户可旋转 */}
        {isExpanded && (
          <Animated.View
            style={[
              styles.menuContainer,
              {
                transform: [
                  {
                    rotate: menuRotation.interpolate({
                      inputRange: [-180, 180],
                      outputRange: ['-180deg', '180deg'],
                    }),
                  },
                ],
              },
            ]}
            {...rotationResponder.panHandlers}
          >
            {menuItems.map((item, index) => renderMenuItem(item, index))}
          </Animated.View>
        )}

        {/* 中心按钮 - 地球 */}
        <TouchableOpacity
          style={styles.ballContainer}
          activeOpacity={0.8}
          onPress={toggleMenu}
        >
          <View style={styles.ball}>
            {/* 地球图标 */}
            <View style={styles.earthIcon}>
              <View style={styles.earthBase} />
              <View style={styles.earthLine1} />
              <View style={styles.earthLine2} />
              <View style={styles.earthContinent1} />
              <View style={styles.earthContinent2} />
            </View>
          </View>
        </TouchableOpacity>
      </Animated.View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    zIndex: 999,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuContainer: {
    position: 'absolute',
    width: MENU_RADIUS * 2 + MENU_ITEM_SIZE,
    height: MENU_RADIUS * 2 + MENU_ITEM_SIZE,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 999,
  },
  overlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    zIndex: 998,
  },
  ballContainer: {
    width: BALL_SIZE,
    height: BALL_SIZE,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  ball: {
    width: BALL_SIZE,
    height: BALL_SIZE,
    borderRadius: BALL_SIZE / 2,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 5,
    borderWidth: 1.5,
    borderColor: '#1A1A1A',
  },
  earthIcon: {
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  earthBase: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#3B82F6',
  },
  earthLine1: {
    position: 'absolute',
    width: 18,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  earthLine2: {
    position: 'absolute',
    width: 1,
    height: 18,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  earthContinent1: {
    position: 'absolute',
    width: 6,
    height: 4,
    borderRadius: 2,
    backgroundColor: '#22C55E',
    top: 4,
    left: 3,
  },
  earthContinent2: {
    position: 'absolute',
    width: 5,
    height: 3,
    borderRadius: 1.5,
    backgroundColor: '#22C55E',
    bottom: 5,
    right: 4,
  },
  menuItemContainer: {
    position: 'absolute',
    width: MENU_ITEM_SIZE,
    height: MENU_ITEM_SIZE + 20,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
  menuItem: {
    width: MENU_ITEM_SIZE,
    height: MENU_ITEM_SIZE,
    borderRadius: MENU_ITEM_SIZE / 2,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
    elevation: 3,
  },
  menuIconWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  menuItemLabel: {
    position: 'absolute',
    bottom: -2,
    fontSize: 9,
    fontWeight: '500',
    color: '#374151',
    textAlign: 'center',
    backgroundColor: 'rgba(255,255,255,0.9)',
    paddingHorizontal: 4,
    paddingVertical: 1,
    borderRadius: 3,
  },
});

export default FloatingBall;
