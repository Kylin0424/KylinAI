// 亲属关系数据

export interface FamilyRelation {
  id: string;
  name: string;
  gender: 'male' | 'female' | 'any';
  generation: number; // 辈分差，0表示同辈，1表示上一辈，-1表示下一辈
  category: 'direct' | 'collateral' | 'inlaw'; // 直系、旁系、姻亲
}

// 所有亲属关系
export const FAMILY_RELATIONS: FamilyRelation[] = [
  // 直系亲属 - 长辈
  { id: 'father', name: '父亲', gender: 'male', generation: 1, category: 'direct' },
  { id: 'mother', name: '母亲', gender: 'female', generation: 1, category: 'direct' },
  { id: 'grandfather', name: '祖父/爷爷', gender: 'male', generation: 2, category: 'direct' },
  { id: 'grandmother', name: '祖母/奶奶', gender: 'female', generation: 2, category: 'direct' },
  { id: 'maternal_grandfather', name: '外祖父/姥爷', gender: 'male', generation: 2, category: 'direct' },
  { id: 'maternal_grandmother', name: '外祖母/姥姥', gender: 'female', generation: 2, category: 'direct' },
  
  // 直系亲属 - 晚辈
  { id: 'son', name: '儿子', gender: 'male', generation: -1, category: 'direct' },
  { id: 'daughter', name: '女儿', gender: 'female', generation: -1, category: 'direct' },
  { id: 'grandson', name: '孙子', gender: 'male', generation: -2, category: 'direct' },
  { id: 'granddaughter', name: '孙女', gender: 'female', generation: -2, category: 'direct' },
  
  // 旁系亲属 - 同辈
  { id: 'older_brother', name: '哥哥', gender: 'male', generation: 0, category: 'collateral' },
  { id: 'younger_brother', name: '弟弟', gender: 'male', generation: 0, category: 'collateral' },
  { id: 'older_sister', name: '姐姐', gender: 'female', generation: 0, category: 'collateral' },
  { id: 'younger_sister', name: '妹妹', gender: 'female', generation: 0, category: 'collateral' },
  { id: 'cousin_male', name: '堂兄弟/表兄弟', gender: 'male', generation: 0, category: 'collateral' },
  { id: 'cousin_female', name: '堂姐妹/表姐妹', gender: 'female', generation: 0, category: 'collateral' },
  
  // 旁系亲属 - 长辈
  { id: 'uncle_paternal', name: '伯父/叔叔', gender: 'male', generation: 1, category: 'collateral' },
  { id: 'aunt_paternal', name: '姑妈', gender: 'female', generation: 1, category: 'collateral' },
  { id: 'uncle_maternal', name: '舅舅', gender: 'male', generation: 1, category: 'collateral' },
  { id: 'aunt_maternal', name: '姨妈', gender: 'female', generation: 1, category: 'collateral' },
  
  // 旁系亲属 - 晚辈
  { id: 'nephew', name: '侄子', gender: 'male', generation: -1, category: 'collateral' },
  { id: 'niece', name: '侄女', gender: 'female', generation: -1, category: 'collateral' },
  
  // 姻亲
  { id: 'spouse', name: '配偶', gender: 'any', generation: 0, category: 'inlaw' },
  { id: 'father_in_law', name: '岳父/公公', gender: 'male', generation: 1, category: 'inlaw' },
  { id: 'mother_in_law', name: '岳母/婆婆', gender: 'female', generation: 1, category: 'inlaw' },
  { id: 'brother_in_law', name: '大伯/小叔/内弟/姐夫', gender: 'male', generation: 0, category: 'inlaw' },
  { id: 'sister_in_law', name: '大姑/小姑/嫂子/弟媳', gender: 'female', generation: 0, category: 'inlaw' },
];

// 成员人数选项（1-99）
export const generateMemberCountOptions = () => {
  return Array.from({ length: 99 }, (_, i) => ({
    label: `${i + 1}人`,
    value: i + 1,
  }));
};

// 获取关系对应的反向关系（用于生成家庭成员）
export const getReverseRelation = (relationId: string, targetGender: 'male' | 'female'): string => {
  const reverseMap: Record<string, Record<string, string>> = {
    father: { male: '儿子', female: '女儿' },
    mother: { male: '儿子', female: '女儿' },
    son: { male: '父亲', female: '母亲' },
    daughter: { male: '父亲', female: '母亲' },
    older_brother: { male: '弟弟', female: '妹妹' },
    younger_brother: { male: '哥哥', female: '姐姐' },
    older_sister: { male: '弟弟', female: '妹妹' },
    younger_sister: { male: '哥哥', female: '姐姐' },
    grandfather: { male: '孙子', female: '孙女' },
    grandmother: { male: '孙子', female: '孙女' },
    uncle_paternal: { male: '侄子', female: '侄女' },
    aunt_paternal: { male: '侄子', female: '侄女' },
    uncle_maternal: { male: '外甥', female: '外甥女' },
    aunt_maternal: { male: '外甥', female: '外甥女' },
  };
  
  return reverseMap[relationId]?.[targetGender] || '亲属';
};

// 扁平化亲属关系，供下拉选择使用
export const getAllRelationsFlat = (): { relation: string; category: string }[] => {
  const categoryNames: Record<string, string> = {
    direct: '直系亲属',
    collateral: '旁系亲属',
    inlaw: '姻亲',
  };
  
  return FAMILY_RELATIONS.map(r => ({
    relation: r.name,
    category: categoryNames[r.category] || '其他',
  }));
};
