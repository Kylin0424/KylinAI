import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Character {
  id: string;
  name: string;
  gender: string;
  age: number;
  height: string;
  occupation: string;
  personality: string;
  experience: string;
  familyBackground: string;
  appearance: string;
  specialTraits: string;
  createdAt: number;
  novelId?: string; // 所属小说ID
  roleType?: 'male_lead' | 'female_lead' | 'npc'; // 角色类型
  relationToProtagonist?: string; // 与主角的关系
}

export interface CharacterRelation {
  id: string;
  characterId: string;
  relatedCharacterId: string;
  relationType: string; // 如：父亲、母亲、配偶、朋友、敌人等
  description: string;
  createdAt: number;
}

const CHARACTERS_KEY = '@novel_app_characters';
const RELATIONS_KEY = '@novel_app_relations';

// 生成唯一ID
export const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
};

// 获取所有角色
export const getAllCharacters = async (): Promise<Character[]> => {
  try {
    const data = await AsyncStorage.getItem(CHARACTERS_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting characters:', error);
    return [];
  }
};

// 保存角色
export const saveCharacter = async (character: Character): Promise<void> => {
  try {
    const characters = await getAllCharacters();
    characters.push(character);
    await AsyncStorage.setItem(CHARACTERS_KEY, JSON.stringify(characters));
  } catch (error) {
    console.error('Error saving character:', error);
    throw error;
  }
};

// 更新角色
export const updateCharacter = async (character: Character): Promise<void> => {
  try {
    const characters = await getAllCharacters();
    const index = characters.findIndex(c => c.id === character.id);
    if (index !== -1) {
      characters[index] = character;
      await AsyncStorage.setItem(CHARACTERS_KEY, JSON.stringify(characters));
    }
  } catch (error) {
    console.error('Error updating character:', error);
    throw error;
  }
};

// 删除角色
export const deleteCharacter = async (characterId: string): Promise<void> => {
  try {
    const characters = await getAllCharacters();
    const filtered = characters.filter(c => c.id !== characterId);
    await AsyncStorage.setItem(CHARACTERS_KEY, JSON.stringify(filtered));
    
    // 同时删除相关的关系
    const relations = await getAllRelations();
    const filteredRelations = relations.filter(
      r => r.characterId !== characterId && r.relatedCharacterId !== characterId
    );
    await AsyncStorage.setItem(RELATIONS_KEY, JSON.stringify(filteredRelations));
  } catch (error) {
    console.error('Error deleting character:', error);
    throw error;
  }
};

// 获取所有关系
export const getAllRelations = async (): Promise<CharacterRelation[]> => {
  try {
    const data = await AsyncStorage.getItem(RELATIONS_KEY);
    return data ? JSON.parse(data) : [];
  } catch (error) {
    console.error('Error getting relations:', error);
    return [];
  }
};

// 获取角色的所有关系
export const getCharacterRelations = async (characterId: string): Promise<CharacterRelation[]> => {
  try {
    const relations = await getAllRelations();
    return relations.filter(
      r => r.characterId === characterId || r.relatedCharacterId === characterId
    );
  } catch (error) {
    console.error('Error getting character relations:', error);
    return [];
  }
};

// 保存关系
export const saveRelation = async (relation: CharacterRelation): Promise<void> => {
  try {
    const relations = await getAllRelations();
    relations.push(relation);
    await AsyncStorage.setItem(RELATIONS_KEY, JSON.stringify(relations));
  } catch (error) {
    console.error('Error saving relation:', error);
    throw error;
  }
};

// 删除关系
export const deleteRelation = async (relationId: string): Promise<void> => {
  try {
    const relations = await getAllRelations();
    const filtered = relations.filter(r => r.id !== relationId);
    await AsyncStorage.setItem(RELATIONS_KEY, JSON.stringify(filtered));
  } catch (error) {
    console.error('Error deleting relation:', error);
    throw error;
  }
};

// 清空所有数据
export const clearAllData = async (): Promise<void> => {
  try {
    await AsyncStorage.multiRemove([CHARACTERS_KEY, RELATIONS_KEY]);
  } catch (error) {
    console.error('Error clearing data:', error);
    throw error;
  }
};

// 获取未关联小说的角色（可用于选择）
export const getAvailableCharacters = async (): Promise<Character[]> => {
  try {
    const characters = await getAllCharacters();
    return characters.filter(c => !c.novelId);
  } catch (error) {
    console.error('Error getting available characters:', error);
    return [];
  }
};

// 获取指定小说的角色
export const getNovelCharacters = async (novelId: string): Promise<Character[]> => {
  try {
    const characters = await getAllCharacters();
    return characters.filter(c => c.novelId === novelId);
  } catch (error) {
    console.error('Error getting novel characters:', error);
    return [];
  }
};

// 关联角色到小说
export const linkCharacterToNovel = async (
  characterId: string,
  novelId: string,
  roleType: 'male_lead' | 'female_lead' | 'npc'
): Promise<void> => {
  try {
    const characters = await getAllCharacters();
    const index = characters.findIndex(c => c.id === characterId);
    if (index !== -1) {
      characters[index].novelId = novelId;
      characters[index].roleType = roleType;
      await AsyncStorage.setItem(CHARACTERS_KEY, JSON.stringify(characters));
    }
  } catch (error) {
    console.error('Error linking character to novel:', error);
    throw error;
  }
};

// 解除角色与小说的关联
export const unlinkCharacterFromNovel = async (characterId: string): Promise<void> => {
  try {
    const characters = await getAllCharacters();
    const index = characters.findIndex(c => c.id === characterId);
    if (index !== -1) {
      characters[index].novelId = undefined;
      characters[index].roleType = undefined;
      await AsyncStorage.setItem(CHARACTERS_KEY, JSON.stringify(characters));
    }
  } catch (error) {
    console.error('Error unlinking character from novel:', error);
    throw error;
  }
};

// 获取角色详情
export const getCharacterById = async (characterId: string): Promise<Character | null> => {
  try {
    const characters = await getAllCharacters();
    return characters.find(c => c.id === characterId) || null;
  } catch (error) {
    console.error('Error getting character:', error);
    return null;
  }
};

// 获取可用角色（按性别筛选）
export const getAvailableCharactersByGender = async (gender?: '男' | '女'): Promise<Character[]> => {
  try {
    const characters = await getAvailableCharacters();
    if (!gender) return characters;
    return characters.filter(c => c.gender === gender);
  } catch (error) {
    console.error('Error getting available characters by gender:', error);
    return [];
  }
};
